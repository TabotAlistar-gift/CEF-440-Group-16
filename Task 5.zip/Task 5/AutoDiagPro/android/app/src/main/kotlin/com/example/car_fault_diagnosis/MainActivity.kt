package com.example.car_fault_diagnosis

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
