class AppStrings {
  static const String appName = 'Car Fault Diagnosis';
  
  // Auth
  static const String login = 'Login';
  static const String register = 'Register';
  static const String email = 'Email';
  static const String password = 'Password';
  static const String forgotPassword = 'Forgot Password?';
  static const String alreadyHaveAccount = 'Already have an account?';
  static const String createAccount = 'Create Account';
  static const String fullName = 'Full Name';
  static const String confirmPassword = 'Confirm Password';
  
  // Dashboard
  static const String dashboard = 'Dashboard';
  static const String scanDashboard = 'Scan Dashboard Light';
  static const String recordEngine = 'Record Engine Sound';
  static const String viewHistory = 'View History';
  static const String findMechanic = 'Find Mechanic';
  static const String maintenance = 'Maintenance';
  static const String settings = 'Settings';
  
  // Diagnosis
  static const String startScanning = 'Start Scanning';
  static const String analyzing = 'Analyzing...';
  static const String diagnosisResult = 'Diagnosis Result';
  static const String possibleCauses = 'Possible Causes';
  static const String recommendations = 'Recommendations';
  static const String severity = 'Severity';
  static const String urgency = 'Urgency';
  
  // Sound
  static const String startRecording = 'Start Recording';
  static const String stopRecording = 'Stop Recording';
  static const String playSound = 'Play Sound';
  static const String detectingFault = 'Detecting Fault...';
  
  // Common
  static const String cancel = 'Cancel';
  static const String save = 'Save';
  static const String ok = 'OK';
  static const String error = 'Error';
  static const String success = 'Success';
  static const String warning = 'Warning';
  static const String noData = 'No data available';
}