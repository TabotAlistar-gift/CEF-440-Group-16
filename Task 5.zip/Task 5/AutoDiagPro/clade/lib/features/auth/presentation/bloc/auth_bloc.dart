import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:equatable/equatable.dart';
import '../../domain/entities/user.dart';
import '../../domain/usecases/auth_usecase.dart';

// Events
abstract class AuthEvent extends Equatable {
  const AuthEvent();

  @override
  List<Object> get props => [];
}

class LoginEvent extends AuthEvent {
  final String email;
  final String password;

  const LoginEvent({
    required this.email,
    required this.password,
  });

  @override
  List<Object> get props => [email, password];
}

class RegisterEvent extends AuthEvent {
  final String name;
  final String email;
  final String password;
  final UserType userType;

  const RegisterEvent({
    required this.name,
    required this.email,
    required this.password,
    required this.userType,
  });

  @override
  List<Object> get props => [name, email, password, userType];
}

class LogoutEvent extends AuthEvent {
  const LogoutEvent();
}

class CheckAuthStatusEvent extends AuthEvent {
  const CheckAuthStatusEvent();
}

class ForgotPasswordEvent extends AuthEvent {
  final String email;

  const ForgotPasswordEvent({required this.email});

  @override
  List<Object> get props => [email];
}

// States
abstract class AuthState extends Equatable {
  const AuthState();

  @override
  List<Object?> get props => [];
}

class AuthInitial extends AuthState {
  const AuthInitial();
}

class AuthLoading extends AuthState {
  const AuthLoading();
}

class AuthSuccess extends AuthState {
  final User user;

  const AuthSuccess({required this.user});

  @override
  List<Object> get props => [user];
}

class AuthError extends AuthState {
  final String message;

  const AuthError({required this.message});

  @override
  List<Object> get props => [message];
}

class AuthUnauthenticated extends AuthState {
  const AuthUnauthenticated();
}

class ForgotPasswordSuccess extends AuthState {
  final String message;

  const ForgotPasswordSuccess({required this.message});

  @override
  List<Object> get props => [message];
}

// BLoC
class AuthBloc extends Bloc<AuthEvent, AuthState> {
  final LoginUseCase _loginUseCase;
  final RegisterUseCase _registerUseCase;
  final LogoutUseCase _logoutUseCase;
  final GetCurrentUserUseCase _getCurrentUserUseCase;
  final ForgotPasswordUseCase? _forgotPasswordUseCase;

  AuthBloc({
    required LoginUseCase loginUseCase,
    required RegisterUseCase registerUseCase,
    required LogoutUseCase logoutUseCase,
    required GetCurrentUserUseCase getCurrentUserUseCase,
    ForgotPasswordUseCase? forgotPasswordUseCase,
  })  : _loginUseCase = loginUseCase,
        _registerUseCase = registerUseCase,
        _logoutUseCase = logoutUseCase,
        _getCurrentUserUseCase = getCurrentUserUseCase,
        _forgotPasswordUseCase = forgotPasswordUseCase,
        super(const AuthInitial()) {
    on<LoginEvent>(_onLogin);
    on<RegisterEvent>(_onRegister);
    on<LogoutEvent>(_onLogout);
    on<CheckAuthStatusEvent>(_onCheckAuthStatus);
    on<ForgotPasswordEvent>(_onForgotPassword);
  }

  Future<void> _onLogin(LoginEvent event, Emitter<AuthState> emit) async {
    emit(const AuthLoading());
    
    try {
      final result = await _loginUseCase.call(LoginParams(
        email: event.email,
        password: event.password,
      ));
      
      result.fold(
        (failure) => emit(AuthError(message: failure.message)),
        (user) => emit(AuthSuccess(user: user)),
      );
    } catch (e) {
      emit(AuthError(message: 'An unexpected error occurred: ${e.toString()}'));
    }
  }

  Future<void> _onRegister(RegisterEvent event, Emitter<AuthState> emit) async {
    emit(const AuthLoading());
    
    try {
      final result = await _registerUseCase.call(RegisterParams(
        name: event.name,
        email: event.email,
        password: event.password,
        userType: event.userType,
      ));
      
      result.fold(
        (failure) => emit(AuthError(message: failure.message)),
        (user) => emit(AuthSuccess(user: user)),
      );
    } catch (e) {
      emit(AuthError(message: 'An unexpected error occurred: ${e.toString()}'));
    }
  }

  Future<void> _onLogout(LogoutEvent event, Emitter<AuthState> emit) async {
    emit(const AuthLoading());
    
    try {
      final result = await _logoutUseCase.call(NoParams());
      
      result.fold(
        (failure) => emit(AuthError(message: failure.message)),
        (_) => emit(const AuthUnauthenticated()),
      );
    } catch (e) {
      emit(AuthError(message: 'An unexpected error occurred: ${e.toString()}'));
    }
  }

  Future<void> _onCheckAuthStatus(
      CheckAuthStatusEvent event, Emitter<AuthState> emit) async {
    emit(const AuthLoading());
    
    try {
      final result = await _getCurrentUserUseCase.call(NoParams());
      
      result.fold(
        (failure) => emit(const AuthUnauthenticated()),
        (user) => emit(AuthSuccess(user: user)),
      );
    } catch (e) {
      emit(const AuthUnauthenticated());
    }
  }

  Future<void> _onForgotPassword(
      ForgotPasswordEvent event, Emitter<AuthState> emit) async {
    emit(const AuthLoading());
    
    try {
      if (_forgotPasswordUseCase != null) {
        final result = await _forgotPasswordUseCase.call(
          ForgotPasswordParams(email: event.email),
        );
        
        result.fold(
          (failure) => emit(AuthError(message: failure.message)),
          (message) => emit(ForgotPasswordSuccess(message: message)),
        );
      } else {
        // Fallback behavior if use case is not provided
        await Future.delayed(const Duration(seconds: 2));
        emit(const ForgotPasswordSuccess(
          message: 'Password reset link sent to your email',
        ));
      }
    } catch (e) {
      emit(AuthError(message: 'Failed to send reset email: ${e.toString()}'));
    }
  }
}