import 'dart:async';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:record/record.dart';
import 'package:audioplayers/audioplayers.dart';
import 'package:path_provider/path_provider.dart';
import '../../../../core/constants/app_colors.dart';
import '../../../../core/constants/app_strings.dart';
import '../../../../core/widgets/custom_button.dart';

class RecordEngineSoundPage extends StatefulWidget {
  const RecordEngineSoundPage({Key? key}) : super(key: key);

  @override
  State<RecordEngineSoundPage> createState() => _RecordEngineSoundPageState();
}

class _RecordEngineSoundPageState extends State<RecordEngineSoundPage>
    with TickerProviderStateMixin {
  final Record _record = Record();
  final AudioPlayer _audioPlayer = AudioPlayer();
  
  bool _isRecording = false;
  bool _hasRecording = false;
  String? _recordingPath;
  Duration _recordingDuration = Duration.zero;
  Timer? _timer;
  
  late AnimationController _pulseController;
  late Animation<double> _pulseAnimation;

  @override
  void initState() {
    super.initState();
    _initializeAnimations();
  }

  void _initializeAnimations() {
    _pulseController = AnimationController(
      duration: const Duration(seconds: 2),
      vsync: this,
    );
    _pulseAnimation = Tween<double>(
      begin: 1.0,
      end: 1.2,
    ).animate(CurvedAnimation(
      parent: _pulseController,
      curve: Curves.easeInOut,
    ));
    _pulseController.repeat(reverse: true);
  }

  @override
  void dispose() {
    _timer?.cancel();
    _record.dispose();
    _audioPlayer.dispose();
    _pulseController.dispose();
    super.dispose();
  }

  Future<void> _startRecording() async {
    try {
      if (await _record.hasPermission()) {
        final directory = await getApplicationDocumentsDirectory();
        final filePath = '${directory.path}/engine_sound_${DateTime.now().millisecondsSinceEpoch}.m4a';
        
        await _record.start(path: filePath);
        setState(() {
          _isRecording = true;
          _hasRecording = false;
          _recordingPath = filePath;
          _recordingDuration = Duration.zero;
        });
        
        _startTimer();
      } else {
        _showPermissionDialog();
      }
    } catch (e) {
      print('Error starting recording: $e');
    }
  }

  Future<void> _stopRecording() async {
    try {
      final path = await _record.stop();
      _timer?.cancel();
      setState(() {
        _isRecording = false;
        _hasRecording = true;
        _recordingPath = path;
      });
    } catch (e) {
      print('Error stopping recording: $e');
    }
  }

  void _startTimer() {
    _timer = Timer.periodic(const Duration(seconds: 1), (timer) {
      setState(() {
        _recordingDuration = Duration(seconds: _recordingDuration.inSeconds + 1);
      });
    });
  }

  Future<void> _playRecording() async {
    if (_recordingPath != null) {
      await _audioPlayer.play(DeviceFileSource(_recordingPath!));
    }
  }

  void _showPermissionDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Microphone Permission'),
        content: const Text('This app needs microphone access to record engine sounds.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () {
              Navigator.pop(context);
              // Open app settings
            },
            child: const Text('Settings'),
          ),
        ],
      ),
    );
  }

  void _analyzeSound() {
    if (_hasRecording && _recordingPath != null) {
      Navigator.pushNamed(
        context,
        '/diagnosis-result',
        arguments: {
          'soundPath': _recor
                    