import 'package:dartz/dartz.dart';
import '../../../core/error/failures.dart';
import '../entities/user.dart';

abstract class AuthRepository {
  /// Login with email and password
  Future<Either<Failure, User>> login({
    required String email,
    required String password,
  });

  /// Register a new user
  Future<Either<Failure, User>> register({
    required String name,
    required String email,
    required String password,
    required UserType userType,
  });

  /// Logout current user
  Future<Either<Failure, void>> logout();

  /// Get current authenticated user
  Future<Either<Failure, User>> getCurrentUser();

  /// Send forgot password email
  Future<Either<Failure, String>> forgotPassword({
    required String email,
  });

  /// Reset password with token
  Future<Either<Failure, String>> resetPassword({
    required String token,
    required String newPassword,
  });

  /// Update user profile
  Future<Either<Failure, User>> updateProfile({
    String? name,
    String? email,
    String? phoneNumber,
  });

  /// Change user password
  Future<Either<Failure, String>> changePassword({
    required String currentPassword,
    required String newPassword,
  });

  /// Verify email with token
  Future<Either<Failure, String>> verifyEmail({
    required String token,
  });

  /// Resend email verification
  Future<Either<Failure, String>> resendEmailVerification();

  /// Check if user is authenticated
  Future<Either<Failure, bool>> isAuthenticated();

  /// Delete user account
  Future<Either<Failure, String>> deleteAccount({
    required String password,
  });

  /// Get cached user data
  Future<Either<Failure, User?>> getCachedUser();

  /// Clear user cache
  Future<Either<Failure, void>> clearCache();
}