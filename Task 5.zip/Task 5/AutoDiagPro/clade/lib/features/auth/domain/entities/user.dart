import 'package:equatable/equatable.dart';

class User extends Equatable {
  final String id;
  final String name;
  final String email;
  final String? location;
  final UserType userType;
  final String? vehicleInfo;
  final String? licensePlate;
  final String? certification;
  final String? specialization;
  final int? yearsOfExperience;
  final DateTime createdAt;

  const User({
    required this.id,
    required this.name,
    required this.email,
    this.location,
    required this.userType,
    this.vehicleInfo,
    this.licensePlate,
    this.certification,
    this.specialization,
    this.yearsOfExperience,
    required this.createdAt,
  });

  @override
  List<Object?> get props => [
        id,
        name,
        email,
        location,
        userType,
        vehicleInfo,
        licensePlate,
        certification,
        specialization,
        yearsOfExperience,
        createdAt,
      ];
}

enum UserType { carOwner, mechanic, admin }