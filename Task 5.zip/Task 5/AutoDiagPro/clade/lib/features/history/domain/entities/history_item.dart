import 'package:equatable/equatable.dart';

enum DiagnosisType { dashboard, sound }

class HistoryItem extends Equatable {
  final String id;
  final String title;
  final String description;
  final DiagnosisType type;
  final String severity;
  final DateTime date;

  const HistoryItem({
    required this.id,
    required this.title,
    required this.description,
    required this.type,
    required this.severity,
    required this.date,
  });

  @override
  List<Object?> get props => [id, title, description, type, severity, date];
}