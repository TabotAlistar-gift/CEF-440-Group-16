import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:equatable/equatable.dart';
import '../../domain/entities/diagnosis_result.dart';

part 'diagnosis_event.dart';
part 'diagnosis_state.dart';

class DiagnosisBloc extends Bloc<DiagnosisEvent, DiagnosisState> {
  DiagnosisBloc() : super(DiagnosisInitial()) {
    on<AnalyzeDashboardLightEvent>(_onAnalyzeDashboardLight);
    on<AnalyzeEngineSoundEvent>(_onAnalyzeEngineSound);
    on<SaveDiagnosisEvent>(_onSaveDiagnosis);
  }

  Future<void> _onAnalyzeDashboardLight(
    AnalyzeDashboardLightEvent event,
    Emitter<DiagnosisState> emit,
  ) async {
    emit(DiagnosisLoading());
    try {
      // Simulate AI analysis
      await Future.delayed(const Duration(seconds: 3));
      
      // Mock diagnosis results
      final results = [
        DiagnosisResult(
          id: '1',
          name: 'Engine Temperature Warning',
          description: 'Engine is running hotter than normal operating temperature',
          severity: Severity.high,
          urgency: Urgency.immediate,
          causes: [
            'Low coolant level',
            'Faulty thermostat',
            'Radiator blockage',
            'Water pump failure',
          ],
          recommendations: [
            'Stop driving immediately and let engine cool',
            'Check coolant level when engine is cold',
            'Visit mechanic for inspection',
            'Do not remove radiator cap when hot',
          ],
          detectedAt: DateTime.now(),
        ),
      ];
      
      emit(DiagnosisSuccess(results: results));
    } catch (e) {
      emit(DiagnosisError(message: 'Failed to analyze image'));
    }
  }

  Future<void> _onAnalyzeEngineSound(
    AnalyzeEngineSoundEvent event,
    Emitter<DiagnosisState> emit,
  ) async {
    emit(DiagnosisLoading());
    try {
      // Simulate AI analysis
      await Future.delayed(const Duration(seconds: 3));
      
      // Mock diagnosis results
      final results = [
        DiagnosisResult(
          id: '2',
          name: 'Engine Knocking Sound',
          description: 'Abnormal knocking sound detected from engine',
          severity: Severity.medium,
          urgency: Urgency.soon,
          causes: [
            'Low octane fuel',
            'Carbon buildup',
            'Worn engine bearings',
            'Faulty spark plugs',
          ],
          recommendations: [
            'Use higher octane fuel',
            'Add fuel system cleaner',
            'Schedule engine inspection',
            'Check and replace spark plugs if needed',
          ],
          detectedAt: DateTime.now(),
        ),
      ];
      
      emit(DiagnosisSuccess(results: results));
    } catch (e) {
      emit(DiagnosisError(message: 'Failed to analyze sound'));
    }
  }

  Future<void> _onSaveDiagnosis(
    SaveDiagnosisEvent event,
    Emitter<DiagnosisState> emit,
  ) async {
    try {
      // Save to local storage or API
      await Future.delayed(const Duration(seconds: 1));
      emit(DiagnosisSaved());
    } catch (e) {
      emit(DiagnosisError(message: 'Failed to save diagnosis'));
    }
  }
}