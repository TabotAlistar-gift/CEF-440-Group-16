import 'package:equatable/equatable.dart';

enum Severity { low, medium, high }
enum Urgency { notUrgent, soon, immediate }

class DiagnosisResult extends Equatable {
  final String id;
  final String name;
  final String description;
  final Severity severity;
  final Urgency urgency;
  final List<String> causes;
  final List<String> recommendations;
  final DateTime detectedAt;
  final String? imagePath;
  final String? soundPath;

  const DiagnosisResult({
    required this.id,
    required this.name,
    required this.description,
    required this.severity,
    required this.urgency,
    required this.causes,
    required this.recommendations,
    required this.detectedAt,
    this.imagePath,
    this.soundPath,
  });

  @override
  List<Object?> get props => [
        id,
        name,
        description,
        severity,
        urgency,
        causes,
        recommendations,
        detectedAt,
        imagePath,
        soundPath,
      ];
}