import 'package:equatable/equatable.dart';

abstract class Failure extends Equatable {
  final String message;
  final int? code;

  const Failure({
    required this.message,
    this.code,
  });

  @override
  List<Object?> get props => [message, code];
}

// ===== Server Failure =====
class ServerFailure extends Failure {
  const ServerFailure({
    required String message,
    int? code,
  }) : super(message: message, code: code);

  factory ServerFailure.fromStatusCode(int statusCode) {
    switch (statusCode) {
      case 400:
        return const ServerFailure(
          message: 'Bad request. Please check your input.',
          code: 400,
        );
      case 401:
        return const ServerFailure(
          message: 'Unauthorized. Please check your credentials.',
          code: 401,
        );
      case 403:
        return const ServerFailure(
          message: 'Forbidden. You don\'t have permission to access this resource.',
          code: 403,
        );
      case 404:
        return const ServerFailure(
          message: 'Resource not found.',
          code: 404,
        );
      case 422:
        return const ServerFailure(
          message: 'Validation error. Please check your input.',
          code: 422,
        );
      case 500:
        return const ServerFailure(
          message: 'Internal server error. Please try again later.',
          code: 500,
        );
      case 502:
        return const ServerFailure(
          message: 'Bad gateway. Please try again later.',
          code: 502,
        );
      case 503:
        return const ServerFailure(
          message: 'Service unavailable. Please try again later.',
          code: 503,
        );
      default:
        return ServerFailure(
          message: 'Unknown server error occurred. Status code: $statusCode',
          code: statusCode,
        );
    }
  }
}

// ===== Network Failure =====
class NetworkFailure extends Failure {
  const NetworkFailure({
    String message = 'No internet connection. Please check your network settings.',
    int? code,
  }) : super(message: message, code: code);
}

// ===== Cache Failure =====
class CacheFailure extends Failure {
  const CacheFailure({
    String message = 'Failed to load cached data.',
    int? code,
  }) : super(message: message, code: code);
}

// ===== Authentication Failure =====
class AuthFailure extends Failure {
  const AuthFailure({
    required String message,
    int? code,
  }) : super(message: message, code: code);

  factory AuthFailure.invalidCredentials() {
    return const AuthFailure(
      message: 'Invalid email or password.',
      code: 401,
    );
  }

  factory AuthFailure.userNotFound() {
    return const AuthFailure(
      message: 'User not found.',
      code: 404,
    );
  }

  factory AuthFailure.emailAlreadyExists() {
    return const AuthFailure(
      message: 'An account with this email already exists.',
      code: 409,
    );
  }

  factory AuthFailure.weakPassword() {
    return const AuthFailure(
      message: 'Password is too weak. Please choose a stronger password.',
      code: 400,
    );
  }

  factory AuthFailure.invalidEmail() {
    return const AuthFailure(
      message: 'Invalid email format.',
      code: 400,
    );
  }

  factory AuthFailure.emailNotVerified() {
    return const AuthFailure(
      message: 'Email not verified. Please check your email for verification link.',
      code: 403,
    );
  }

  factory AuthFailure.accountDisabled() {
    return const AuthFailure(
      message: 'This account has been disabled. Please contact support.',
      code: 403,
    );
  }

  factory AuthFailure.sessionExpired() {
    return const AuthFailure(
      message: 'Your session has expired. Please login again.',
      code: 401,
    );
  }

  factory AuthFailure.invalidToken() {
    return const AuthFailure(
      message: 'Invalid or expired token.',
      code: 401,
    );
  }

  factory AuthFailure.passwordMismatch() {
    return const AuthFailure(
      message: 'Current password is incorrect.',
      code: 400,
    );
  }
}

// ===== Validation Failure =====
class ValidationFailure extends Failure {
  const ValidationFailure({
    required String message,
    int? code,
  }) : super(message: message, code: code);

  factory ValidationFailure.emptyField(String fieldName) {
    return ValidationFailure(
      message: '$fieldName cannot be empty.',
      code: 400,
    );
  }

  factory ValidationFailure.invalidFormat(String fieldName) {
    return ValidationFailure(
      message: 'Invalid $fieldName format.',
      code: 400,
    );
  }

  factory ValidationFailure.tooShort(String fieldName, int minLength) {
    return ValidationFailure(
      message: '$fieldName must be at least $minLength characters long.',
      code: 400,
    );
  }

  factory ValidationFailure.tooLong(String fieldName, int maxLength) {
    return ValidationFailure(
      message: '$fieldName must not exceed $maxLength characters.',
      code: 400,
    );
  }
}

// ===== Permission Failure =====
class PermissionFailure extends Failure {
  const PermissionFailure({
    String message = 'You don\'t have permission to perform this action.',
    int? code = 403,
  }) : super(message: message, code: code);
}

// ===== Unknown Failure =====
class UnknownFailure extends Failure {
  const UnknownFailure({
    String message = 'An unknown error occurred.',
    int? code,
  }) : super(message: message, code: code);
}