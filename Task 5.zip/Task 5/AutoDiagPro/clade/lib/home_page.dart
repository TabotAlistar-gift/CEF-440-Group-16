import 'package:flutter/material.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  String? selectedCarMake;
  String? selectedSymptom;
  List<String> diagnosisResults = [];

  final List<String> carMakes = [
    'Toyota',
    'Honda',
    'Ford',
    'Chevrolet',
    'BMW',
    'Mercedes-Benz',
    'Audi',
    'Volkswagen',
    'Nissan',
    'Hyundai',
  ];

  final List<String> symptoms = [
    'Engine won\'t start',
    'Strange noises from engine',
    'Overheating',
    'Poor fuel economy',
    'Rough idle',
    'Brake issues',
    'Transmission problems',
    'Electrical issues',
    'Exhaust smoke',
    'Steering problems',
  ];

  final Map<String, List<String>> symptomDiagnosis = {
    'Engine won\'t start': [
      'Check battery connections and charge level',
      'Inspect spark plugs and ignition system',
      'Verify fuel delivery system',
      'Check starter motor',
    ],
    'Strange noises from engine': [
      'Check engine oil level and quality',
      'Inspect timing belt/chain',
      'Check for loose components',
      'Examine exhaust system',
    ],
    'Overheating': [
      'Check coolant level and leaks',
      'Inspect radiator and cooling fans',
      'Check thermostat operation',
      'Examine water pump',
    ],
    'Poor fuel economy': [
      'Check air filter condition',
      'Inspect oxygen sensors',
      'Check tire pressure',
      'Clean fuel injectors',
    ],
    'Rough idle': [
      'Clean throttle body',
      'Check vacuum leaks',
      'Inspect idle air control valve',
      'Replace spark plugs if needed',
    ],
    'Brake issues': [
      'Check brake fluid level',
      'Inspect brake pads and rotors',
      'Check brake lines for leaks',
      'Test brake master cylinder',
    ],
    'Transmission problems': [
      'Check transmission fluid level and condition',
      'Inspect transmission filter',
      'Check for error codes',
      'Examine clutch system (manual)',
    ],
    'Electrical issues': [
      'Check battery and alternator',
      'Inspect fuses and relays',
      'Test electrical connections',
      'Scan for error codes',
    ],
    'Exhaust smoke': [
      'Check engine oil condition',
      'Inspect piston rings and valves',
      'Check coolant system for leaks',
      'Examine turbocharger (if equipped)',
    ],
    'Steering problems': [
      'Check power steering fluid',
      'Inspect steering components',
      'Check wheel alignment',
      'Examine tie rods and ball joints',
    ],
  };

  void _performDiagnosis() {
    if (selectedSymptom != null) {
      setState(() {
        diagnosisResults = symptomDiagnosis[selectedSymptom!] ?? [];
      });
    }
  }

  void _resetDiagnosis() {
    setState(() {
      selectedCarMake = null;
      selectedSymptom = null;
      diagnosisResults = [];
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Car Fault Diagnosis'),
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            // Header Card
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  children: [
                    Icon(
                      Icons.car_repair,
                      size: 48,
                      color: Theme.of(context).primaryColor,
                    ),
                    const SizedBox(height: 8),
                    Text(
                      'Car Fault Diagnosis Tool',
                      style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                        fontWeight: FontWeight.bold,
                        color: Theme.of(context).primaryColor,
                      ),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      'Select your car make and describe the symptoms to get diagnostic suggestions',
                      style: Theme.of(context).textTheme.bodyMedium,
                      textAlign: TextAlign.center,
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 20),

            // Car Make Selection
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Icon(
                          Icons.directions_car,
                          color: Theme.of(context).primaryColor,
                        ),
                        const SizedBox(width: 8),
                        Text(
                          'Select Car Make',
                          style: Theme.of(context).textTheme.titleMedium?.copyWith(
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 12),
                    DropdownButtonFormField<String>(
                      value: selectedCarMake,
                      decoration: const InputDecoration(
                        border: OutlineInputBorder(),
                        hintText: 'Choose your car make',
                      ),
                      items: carMakes.map((make) {
                        return DropdownMenuItem(
                          value: make,
                          child: Text(make),
                        );
                      }).toList(),
                      onChanged: (value) {
                        setState(() {
                          selectedCarMake = value;
                        });
                      },
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 16),

            // Symptom Selection
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Icon(
                          Icons.warning_amber,
                          color: Colors.orange,
                        ),
                        const SizedBox(width: 8),
                        Text(
                          'Describe the Problem',
                          style: Theme.of(context).textTheme.titleMedium?.copyWith(
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 12),
                    DropdownButtonFormField<String>(
                      value: selectedSymptom,
                      decoration: const InputDecoration(
                        border: OutlineInputBorder(),
                        hintText: 'Select the main symptom',
                      ),
                      items: symptoms.map((symptom) {
                        return DropdownMenuItem(
                          value: symptom,
                          child: Text(symptom),
                        );
                      }).toList(),
                      onChanged: (value) {
                        setState(() {
                          selectedSymptom = value;
                          diagnosisResults = [];
                        });
                      },
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 20),

            // Action Buttons
            Row(
              children: [
                Expanded(
                  child: ElevatedButton.icon(
                    onPressed: selectedSymptom != null ? _performDiagnosis : null,
                    icon: const Icon(Icons.search),
                    label: const Text('Diagnose'),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: _resetDiagnosis,
                    icon: const Icon(Icons.refresh),
                    label: const Text('Reset'),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 20),

            // Diagnosis Results
            if (diagnosisResults.isNotEmpty) ...[
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Icon(
                            Icons.build,
                            color: Colors.green,
                          ),
                          const SizedBox(width: 8),
                          Text(
                            'Diagnostic Suggestions',
                            style: Theme.of(context).textTheme.titleMedium?.copyWith(
                              fontWeight: FontWeight.bold,
                              color: Colors.green,
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 12),
                      Text(
                        'Problem: $selectedSymptom',
                        style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                      const SizedBox(height: 12),
                      Text(
                        'Recommended checks:',
                        style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                      const SizedBox(height: 8),
                      ...diagnosisResults.asMap().entries.map((entry) {
                        return Padding(
                          padding: const EdgeInsets.only(bottom: 8.0),
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Container(
                                width: 24,
                                height: 24,
                                decoration: BoxDecoration(
                                  color: Theme.of(context).primaryColor,
                                  shape: BoxShape.circle,
                                ),
                                child: Center(
                                  child: Text(
                                    '${entry.key + 1}',
                                    style: const TextStyle(
                                      color: Colors.white,
                                      fontSize: 12,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                ),
                              ),
                              const SizedBox(width: 12),
                              Expanded(
                                child: Text(
                                  entry.value,
                                  style: Theme.of(context).textTheme.bodyMedium,
                                ),
                              ),
                            ],
                          ),
                        );
                      }).toList(),
                      const SizedBox(height: 12),
                      Container(
                        padding: const EdgeInsets.all(12),
                        decoration: BoxDecoration(
                          color: Colors.amber.shade50,
                          border: Border.all(color: Colors.amber.shade200),
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: Row(
                          children: [
                            Icon(
                              Icons.info_outline,
                              color: Colors.amber.shade700,
                              size: 20,
                            ),
                            const SizedBox(width: 8),
                            Expanded(
                              child: Text(
                                'Disclaimer: These are general suggestions. For complex issues, consult a professional mechanic.',
                                style: TextStyle(
                                  color: Colors.amber.shade700,
                                  fontSize: 12,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }
}