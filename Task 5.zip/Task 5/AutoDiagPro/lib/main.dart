import 'package:car_fault_diagnosis/core/constants/app_colors.dart';
import 'package:car_fault_diagnosis/core/constants/app_dimensions.dart';
import 'package:car_fault_diagnosis/core/constants/app_strings.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:get_it/get_it.dart';

// Core imports
import 'core/network/api_client.dart';
import 'core/network/endpoints.dart';
// Added for CheckAuthStatusUseCase below if needed

// Config imports
import 'config/routes/app_routes.dart';
import 'config/theme/app_theme.dart';

// Auth Feature imports
import 'features/auth/data/datasources/auth_remote_data_source.dart';
import 'features/auth/data/repositories/auth_repository_impl.dart';
import 'features/auth/domain/repositories/auth_repository.dart';
import 'features/auth/domain/usecases/login_usecase.dart';
import 'features/auth/domain/usecases/register_usecase.dart';
import 'features/auth/presentation/bloc/auth_bloc.dart';
import 'features/auth/presentation/pages/login_page.dart';
import 'features/auth/presentation/pages/register_page.dart';

// Diagnosis Feature imports
import 'features/diagnosis/data/datasources/diagnosis_remote_data_source.dart';
import 'features/diagnosis/data/repositories/diagnosis_repository_impl.dart';
import 'features/diagnosis/domain/repositories/diagnosis_repository.dart';
import 'features/diagnosis/domain/usecases/analyze_dashboard_light_usecase.dart';
import 'features/diagnosis/domain/usecases/analyze_engine_sound_usecase.dart';
import 'features/diagnosis/domain/usecases/save_diagnosis_usecase.dart';
import 'features/diagnosis/presentation/bloc/diagnosis_bloc.dart';
import 'features/diagnosis/presentation/pages/diagnosis_result_page.dart';
import 'features/diagnosis/presentation/pages/record_engine_sound_page.dart';
import 'features/diagnosis/presentation/pages/scan_dashboard_page.dart';

// Other Feature imports
import 'features/dashboard/presentation/pages/dashboard_page.dart';
import 'features/history/presentation/pages/history_page.dart';
import 'features/mechanic/presentation/pages/find_mechanic_page.dart';
import 'features/profile/presentation/pages/profile_page.dart';
import 'features/settings/presentation/pages/settings_page.dart';

final sl = GetIt.instance; // sl = service locator

void initDependencies() {
  // Core
  sl.registerLazySingleton<ApiClient>(() => ApiClient(baseUrl: Endpoints.baseUrl));

  // Auth Feature
  sl.registerFactory<AuthRemoteDataSource>(
    () => AuthRemoteDataSourceImpl(apiClient: sl()),
  );
  sl.registerFactory<AuthRepository>(
    () => AuthRepositoryImpl(remoteDataSource: sl()),
  );
  sl.registerFactory(() => LoginUseCase(sl()));
  sl.registerFactory(() => RegisterUseCase(sl()));
  sl.registerFactory(() => AuthBloc(
        loginUseCase: sl(),
        registerUseCase: sl(),
        authRepository: sl(), // Pass repository for logout/checkAuth
      ));

  // Diagnosis Feature
  sl.registerFactory<DiagnosisRemoteDataSource>(
    () => DiagnosisRemoteDataSourceImpl(apiClient: sl()),
  );
  sl.registerFactory<DiagnosisRepository>(
    () => DiagnosisRepositoryImpl(remoteDataSource: sl()),
  );
  sl.registerFactory(() => AnalyzeDashboardLightUseCase(sl()));
  sl.registerFactory(() => AnalyzeEngineSoundUseCase(sl()));
  sl.registerFactory(() => SaveDiagnosisUseCase(sl()));
  sl.registerFactory(() => DiagnosisBloc(
        analyzeDashboardLightUseCase: sl(),
        analyzeEngineSoundUseCase: sl(),
        saveDiagnosisUseCase: sl(),
      ));

  // History, Mechanic, Profile, Settings (will use their respective pages directly for now)
  // If they need BLoC, register them similarly.
}

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  initDependencies();
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MultiBlocProvider(
      providers: [
        BlocProvider<AuthBloc>(
          create: (context) => sl<AuthBloc>()..add(CheckAuthEvent()), // Check auth status on app start
        ),
        BlocProvider<DiagnosisBloc>(
          create: (context) => sl<DiagnosisBloc>(),
        ),
        // Add other BLoC providers here as your app grows
      ],
      child: MaterialApp(
        title: AppStrings.appName,
        theme: AppTheme.lightTheme,
        debugShowCheckedModeBanner: false,
        initialRoute: AppRoutes.splash, // Or AppRoutes.login if no splash
        routes: {
          AppRoutes.splash: (context) => const _SplashPage(), // A simple splash to check auth
          AppRoutes.login: (context) => const LoginPage(),
          AppRoutes.register: (context) => const RegisterPage(),
          AppRoutes.dashboard: (context) => const DashboardPage(),
          AppRoutes.scanDashboardLight: (context) => const ScanDashboardPage(),
          AppRoutes.recordEngineSound: (context) => const RecordEngineSoundPage(),
          AppRoutes.diagnosisResult: (context) {
            final results = ModalRoute.of(context)!.settings.arguments as List;
            return DiagnosisResultPage(results: results.cast());
          },
          AppRoutes.history: (context) => const HistoryPage(),
          AppRoutes.findMechanic: (context) => const FindMechanicPage(),
          AppRoutes.profile: (context) => const ProfilePage(),
          AppRoutes.settings: (context) => const SettingsPage(),
        },
      ),
    );
  }
}

// Simple Splash Screen to handle initial authentication check
class _SplashPage extends StatelessWidget {
  const _SplashPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return BlocListener<AuthBloc, AuthState>(
      listener: (context, state) {
        if (state is AuthSuccess) {
          Navigator.of(context).pushReplacementNamed(AppRoutes.dashboard);
        } else if (state is AuthInitial || state is AuthError) {
          Navigator.of(context).pushReplacementNamed(AppRoutes.login);
        }
      },
      child: const Scaffold(
        backgroundColor: AppColors.primary,
        body: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              CircularProgressIndicator(color: Colors.white),
              SizedBox(height: AppDimensions.spaceLarge),
              Text(
                'Initializing App...',
                style: TextStyle(color: Colors.white, fontSize: AppDimensions.fontSizeLarge),
              ),
            ],
          ),
        ),
      ),
    );
  }
}