class Endpoints {
  static const String baseUrl = 'https://api.yourcarapp.com'; // Replace with your actual API base URL

  // Auth
  static const String login = '/auth/login';
  static const String register = '/auth/register';
  static const String checkAuth = '/auth/check'; // Example endpoint

  // Diagnosis
  static const String analyzeDashboardLight = '/diagnosis/dashboard-light';
  static const String analyzeEngineSound = '/diagnosis/engine-sound';
  static const String saveDiagnosis = '/diagnosis'; // POST to save a new diagnosis

  // History
  static const String getHistory = '/history';

  // Mechanic
  static const String getNearbyMechanics = '/mechanics/nearby';
}