import 'dart:convert';
import 'package:http/http.dart' as http;
import '../errors/exceptions.dart';

class ApiClient {
  final String baseUrl;
  final http.Client httpClient;

  ApiClient({required this.baseUrl, http.Client? httpClient})
      : httpClient = httpClient ?? http.Client();

  Future<Map<String, dynamic>> get(String path, {Map<String, String>? headers}) async {
    final response = await httpClient.get(Uri.parse('$baseUrl$path'), headers: headers);
    return _handleResponse(response);
  }

  Future<Map<String, dynamic>> post(String path, {Map<String, dynamic>? body, Map<String, String>? headers}) async {
    final response = await httpClient.post(
      Uri.parse('$baseUrl$path'),
      headers: {'Content-Type': 'application/json', ...?headers},
      body: json.encode(body),
    );
    return _handleResponse(response);
  }

  Future<Map<String, dynamic>> put(String path, {Map<String, dynamic>? body, Map<String, String>? headers}) async {
    final response = await httpClient.put(
      Uri.parse('$baseUrl$path'),
      headers: {'Content-Type': 'application/json', ...?headers},
      body: json.encode(body),
    );
    return _handleResponse(response);
  }

  Future<Map<String, dynamic>> delete(String path, {Map<String, String>? headers}) async {
    final response = await httpClient.delete(Uri.parse('$baseUrl$path'), headers: headers);
    return _handleResponse(response);
  }

  Map<String, dynamic> _handleResponse(http.Response response) {
    if (response.statusCode >= 200 && response.statusCode < 300) {
      return json.decode(response.body);
    } else if (response.statusCode == 401 || response.statusCode == 403) {
      throw AuthException(message: json.decode(response.body)['message'] ?? 'Unauthorized');
    } else if (response.statusCode >= 400 && response.statusCode < 500) {
      throw ServerException(message: json.decode(response.body)['message'] ?? 'Client Error');
    } else if (response.statusCode >= 500) {
      throw ServerException(message: json.decode(response.body)['message'] ?? 'Server Error');
    } else {
      throw ServerException(message: 'Unknown error occurred: ${response.statusCode}');
    }
  }
}