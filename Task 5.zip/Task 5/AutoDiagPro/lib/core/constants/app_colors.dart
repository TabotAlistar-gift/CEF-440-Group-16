import 'package:flutter/material.dart';

class AppColors {
  static const Color primary = Color(0xFF007BFF); // Blue
  static const Color primaryLight = Color(0xFF66B2FF);
  static const Color primaryDark = Color(0xFF0056B3);

  static const Color secondary = Color(0xFF28A745); // Green
  static const Color secondaryLight = Color(0xFF63D779);
  static const Color secondaryDark = Color(0xFF1E7E34);

  static const Color background = Color(0xFFF8F9FA); // Light Grey
  static const Color surface = Color(0xFFFFFFFF); // White

  static const Color textPrimary = Color(0xFF212529); // Dark Grey
  static const Color textSecondary = Color(0xFF6C757D); // Medium Grey
  static const Color textLight = Color(0xFFADB5BD); // Light Grey text

  static const Color error = Color(0xFFDC3545); // Red
  static const Color warning = Color(0xFFFFC107); // Yellow
  static const Color success = Color(0xFF28A745); // Green (same as secondary for now)
  static const Color info = Color(0xFF17A2B8); // Cyan

  static const Color divider = Color(0xFFDEE2E6); // Lighter grey for dividers

  // Specific colors for diagnosis types
  static const Color dashboardLight = Color(0xFFFD7E14); // Orange
  static const Color engineSound = Color(0xFF6F42C1); // Purple
}