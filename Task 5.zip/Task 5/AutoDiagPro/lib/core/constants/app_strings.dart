class AppStrings {
  // General
  static const String appName = 'Car Fault Diagnosis';
  static const String ok = 'OK';
  static const String cancel = 'Cancel';
  static const String submit = 'Submit';
  static const String loading = 'Loading...';
  static const String somethingWentWrong = 'Something went wrong.';
  static const String noInternetConnection = 'No internet connection.';

  // Auth Feature
  static const String loginTitle = 'Welcome Back!';
  static const String registerTitle = 'Create Your Account';
  static const String emailHint = 'Email';
  static const String passwordHint = 'Password';
  static const String confirmPasswordHint = 'Confirm Password';
  static const String nameHint = 'Full Name';
  static const String loginButton = 'Login';
  static const String registerButton = 'Register';
  static const String forgotPassword = 'Forgot Password?';
  static const String dontHaveAccount = 'Don\'t have an account?';
  static const String alreadyHaveAccount = 'Already have an account?';
  static const String signUpNow = 'Sign Up Now';
  static const String signInNow = 'Sign In Now';
  static const String userTypeQuestion = 'I am a:';
  static const String carOwner = 'Car Owner';
  static const String mechanic = 'Mechanic';

  // Dashboard Feature
  static const String homeWelcome = 'Welcome back,';
  static const String dashboardTitle = 'Dashboard';
  static const String scanDashboardLight = 'Scan Dashboard Light';
  static const String recordEngineSound = 'Record Engine Sound';
  static const String findMechanic = 'Find Nearby Mechanics';
  static const String viewHistory = 'View Diagnosis History';

  // Diagnosis Feature
  static const String diagnosisResults = 'Diagnosis Results';
  static const String scanDashboardInstructions = 'Point your camera at the dashboard warning light.';
  static const String recordSoundInstructions = 'Record the sound of your engine for analysis.';
  static const String retakePhoto = 'Retake Photo';
  static const String reRecordSound = 'Re-record Sound';
  static const String analyze = 'Analyze';
  static const String saveDiagnosis = 'Save Diagnosis';
  static const String diagnosisSavedSuccessfully = 'Diagnosis saved successfully!';
  static const String causes = 'Potential Causes:';
  static const String recommendations = 'Recommendations:';
  static const String severity = 'Severity:';
  static const String urgency = 'Urgency:';

  // History Feature
  static const String noHistoryFound = 'No diagnosis history found.';
  static const String yourHistoryWillAppearHere = 'Your diagnosis history will appear here.';

  // Mechanic Feature
  static const String searchMechanics = 'Search for mechanics...';
  static const String nearbyMechanics = 'Nearby Mechanics';
  static const String sort = 'Sort';
  static const String callMechanic = 'Call Mechanic';
  static const String getDirections = 'Get Directions';
  static const String specializations = 'Specializations:';
  static const String reviews = 'reviews';

  // Profile Feature
  static const String profileTitle = 'Profile';
  static const String editProfile = 'Edit Profile';
  static const String logout = 'Logout';

  // Settings Feature
  static const String settingsTitle = 'Settings';
  static const String generalSettings = 'General';
  static const String notifications = 'Notifications';
  static const String appTheme = 'App Theme';
  static const String privacyPolicy = 'Privacy Policy';
  static const String termsOfService = 'Terms of Service';
  static const String aboutApp = 'About App';
}