import 'package:flutter/material.dart';
import '../constants/app_colors.dart';
import '../constants/app_dimensions.dart';
import 'loading_widget.dart'; // Import LoadingWidget

class CustomButton extends StatelessWidget {
  final String text;
  final VoidCallback? onPressed; // Made nullable
  final bool isLoading;
  final Color? color;
  final Color? textColor;
  final double? width;
  final double? height;
  final EdgeInsetsGeometry? padding;
  final BorderRadiusGeometry? borderRadius;
  final BorderSide? borderSide;
  final TextStyle? textStyle;
  final IconData? icon; // Now an optional property for all constructors

  // Primary constructor for a regular button (no icon by default)
  const CustomButton({
    Key? key,
    required this.text,
    this.onPressed, // Now nullable
    this.isLoading = false,
    this.color = AppColors.primary,
    this.textColor = Colors.white,
    this.width = double.infinity,
    this.height = AppDimensions.buttonHeight,
    this.padding,
    this.borderRadius,
    this.borderSide,
    this.textStyle,
    this.icon, // Optional icon for regular buttons too
  }) : super(key: key);

  // Named constructor for an icon button (icon is typically provided here)
  const CustomButton.icon({
    Key? key,
    required this.text,
    required this.icon, // Icon is required for this named constructor
    this.onPressed, // Now nullable
    this.isLoading = false,
    this.color = AppColors.primary,
    this.textColor = Colors.white,
    this.width = double.infinity,
    this.height = AppDimensions.buttonHeight,
    this.padding,
    this.borderRadius,
    this.borderSide,
    this.textStyle,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: width,
      height: height,
      child: ElevatedButton(
        onPressed: isLoading ? null : onPressed, // Handle null onPressed for loading state
        style: ElevatedButton.styleFrom(
          backgroundColor: color,
          foregroundColor: textColor,
          padding: padding,
          shape: RoundedRectangleBorder(
            borderRadius: borderRadius ?? BorderRadius.circular(AppDimensions.borderRadiusLarge),
            side: borderSide ?? BorderSide.none,
          ),
          textStyle: textStyle,
        ),
        child: isLoading
            ? const LoadingWidget(
                color: Colors.white,
                size: 24,
              )
            : (icon != null // Check if an icon is provided
                ? Row(
                    mainAxisSize: MainAxisSize.min,
                    mainAxisAlignment: MainAxisAlignment.center, // Center content
                    children: [
                      Icon(icon, color: textColor),
                      const SizedBox(width: 8),
                      Text(
                        text,
                        style: TextStyle(
                          fontSize: AppDimensions.fontSizeLarge,
                          fontWeight: FontWeight.w600,
                          color: textColor,
                        ),
                      ),
                    ],
                  )
                : Text( // If no icon, just show text
                    text,
                    style: TextStyle(
                      fontSize: AppDimensions.fontSizeLarge,
                      fontWeight: FontWeight.w600,
                      color: textColor,
                    ),
                  )),
      ),
    );
  }
}