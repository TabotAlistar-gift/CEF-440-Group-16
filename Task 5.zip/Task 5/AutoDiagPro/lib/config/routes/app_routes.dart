class AppRoutes {
  static const String splash = '/';
  static const String login = '/login';
  static const String register = '/register';
  static const String dashboard = '/dashboard';
  static const String scanDashboardLight = '/scanDashboardLight';
  static const String recordEngineSound = '/recordEngineSound';
  static const String diagnosisResult = '/diagnosisResult';
  static const String history = '/history';
  static const String findMechanic = '/findMechanic';
  static const String profile = '/profile';
  static const String settings = '/settings';
}