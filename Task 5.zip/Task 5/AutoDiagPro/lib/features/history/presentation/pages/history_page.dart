import 'package:car_fault_diagnosis/core/utils/helpers.dart';
import 'package:flutter/material.dart';
import '../../../../core/constants/app_colors.dart';
import '../../../../core/constants/app_dimensions.dart';
import '../../../../core/constants/app_strings.dart';
import '../../../../core/utils/formatters.dart'; // Import for date formatting
import '../../domain/entities/history_item.dart';

class HistoryPage extends StatelessWidget {
  const HistoryPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    // Mock data - In a real app, this would come from a HistoryBloc
    // which would fetch from a repository (local or remote)
    final List<HistoryItem> historyItems = [
      HistoryItem(
        id: '1',
        title: 'Engine Temperature Warning',
        description: 'High temperature detected',
        type: DiagnosisType.dashboard,
        severity: 'High',
        date: DateTime.now().subtract(const Duration(days: 2)),
      ),
      HistoryItem(
        id: '2',
        title: 'Engine Knocking Sound',
        description: 'Abnormal sound detected',
        type: DiagnosisType.sound,
        severity: 'Medium',
        date: DateTime.now().subtract(const Duration(days: 5)),
      ),
      HistoryItem(
        id: '3',
        title: 'Oil Pressure Warning',
        description: 'Low oil pressure detected',
        type: DiagnosisType.dashboard,
        severity: 'High',
        date: DateTime.now().subtract(const Duration(days: 10)),
      ),
      HistoryItem(
        id: '4',
        title: 'Brake Fluid Low',
        description: 'Brake fluid level is below minimum',
        type: DiagnosisType.dashboard,
        severity: 'Low',
        date: DateTime.now().subtract(const Duration(days: 15)),
      ),
    ];

    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        title: const Text(AppStrings.viewHistory),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.filter_list, color: Colors.white),
            onPressed: () {
              // Show filter options - implement later
              Helpers.showToast('Filter options coming soon!');
            },
          ),
        ],
      ),
      body: historyItems.isEmpty
          ? _buildEmptyState(context)
          : ListView.builder(
              padding: const EdgeInsets.all(AppDimensions.paddingMedium),
              itemCount: historyItems.length,
              itemBuilder: (context, index) {
                final item = historyItems[index];
                return _HistoryItemCard(item: item);
              },
            ),
    );
  }

  Widget _buildEmptyState(BuildContext context) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            Icons.history,
            size: AppDimensions.iconSizeXLarge * 1.5,
            color: AppColors.textSecondary.withOpacity(0.5),
          ),
          const SizedBox(height: AppDimensions.spaceMedium),
          Text(
            AppStrings.noHistoryFound,
            style: Theme.of(context).textTheme.headlineMedium?.copyWith(
                  color: AppColors.textSecondary,
                ),
          ),
          const SizedBox(height: AppDimensions.spaceSmall),
          Text(
            AppStrings.yourHistoryWillAppearHere,
            style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                  color: AppColors.textSecondary,
                ),
          ),
        ],
      ),
    );
  }
}

class _HistoryItemCard extends StatelessWidget {
  final HistoryItem item;

  const _HistoryItemCard({
    Key? key,
    required this.item,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final Color severityColor = item.severity == 'High'
        ? AppColors.error
        : item.severity == 'Medium'
            ? AppColors.warning
            : AppColors.success;

    return Container(
      margin: const EdgeInsets.only(bottom: AppDimensions.spaceMedium),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(AppDimensions.borderRadiusLarge),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 10,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Material(
        color: Colors.transparent,
        borderRadius: BorderRadius.circular(AppDimensions.borderRadiusLarge),
        child: InkWell(
          borderRadius: BorderRadius.circular(AppDimensions.borderRadiusLarge),
          onTap: () {
            // Navigate to detail page of the diagnosis, perhaps
            // by passing the HistoryItem to a DiagnosisDetailPage
            Helpers.showToast('Details for "${item.title}"');
          },
          child: Padding(
            padding: const EdgeInsets.all(AppDimensions.paddingMedium),
            child: Row(
              children: [
                Container(
                  width: 50,
                  height: 50,
                  decoration: BoxDecoration(
                    color: item.type == DiagnosisType.dashboard
                        ? AppColors.dashboardLight.withOpacity(0.1)
                        : AppColors.engineSound.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(AppDimensions.borderRadiusLarge),
                  ),
                  child: Icon(
                    item.type == DiagnosisType.dashboard
                        ? Icons.camera_alt
                        : Icons.mic,
                    color: item.type == DiagnosisType.dashboard
                        ? AppColors.dashboardLight
                        : AppColors.engineSound,
                    size: AppDimensions.iconSizeLarge,
                  ),
                ),
                const SizedBox(width: AppDimensions.spaceMedium),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        item.title,
                        style: Theme.of(context).textTheme.headlineSmall,
                      ),
                      const SizedBox(height: AppDimensions.spaceSmall),
                      Text(
                        item.description,
                        style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                              color: AppColors.textSecondary,
                            ),
                      ),
                      const SizedBox(height: AppDimensions.spaceSmall),
                      Row(
                        children: [
                          Icon(
                            Icons.calendar_today,
                            size: AppDimensions.iconSizeSmall,
                            color: AppColors.textSecondary,
                          ),
                          const SizedBox(width: AppDimensions.spaceSmall / 2),
                          Text(
                            _formatDate(item.date),
                            style: Theme.of(context).textTheme.labelSmall,
                          ),
                          const SizedBox(width: AppDimensions.spaceMedium),
                          Container(
                            padding: const EdgeInsets.symmetric(
                              horizontal: AppDimensions.paddingSmall,
                              vertical: AppDimensions.paddingSmall / 2,
                            ),
                            decoration: BoxDecoration(
                              color: severityColor.withOpacity(0.1),
                              borderRadius: BorderRadius.circular(AppDimensions.borderRadiusLarge),
                            ),
                            child: Text(
                              item.severity,
                              style: Theme.of(context).textTheme.labelLarge?.copyWith(
                                    color: severityColor,
                                    fontWeight: FontWeight.w600,
                                  ),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                Icon(
                  Icons.chevron_right,
                  color: AppColors.textSecondary,
                  size: AppDimensions.iconSizeMedium,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  String _formatDate(DateTime date) {
    final now = DateTime.now();
    final difference = now.difference(date);

    if (difference.inDays == 0) {
      return 'Today';
    } else if (difference.inDays == 1) {
      return 'Yesterday';
    } else if (difference.inDays < 7) {
      return '${difference.inDays} days ago';
    } else {
      return Formatters.formatDate(date); // Use the formatter from core
    }
  }
}