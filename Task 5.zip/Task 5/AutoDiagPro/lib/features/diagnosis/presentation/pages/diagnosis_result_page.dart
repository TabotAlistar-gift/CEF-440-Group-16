import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../../../../config/routes/app_routes.dart';
import '../../../../core/constants/app_colors.dart';
import '../../../../core/constants/app_dimensions.dart';
import '../../../../core/constants/app_strings.dart';
import '../../../../core/utils/helpers.dart';
import '../../../../core/widgets/custom_button.dart';
import '../../domain/entities/diagnosis_result.dart';
import '../bloc/diagnosis_bloc.dart';

class DiagnosisResultPage extends StatelessWidget {
  final List<DiagnosisResult> results;

  const DiagnosisResultPage({Key? key, required this.results}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    if (results.isEmpty) {
      return Scaffold(
        appBar: AppBar(title: const Text(AppStrings.diagnosisResults)),
        body: const Center(
          child: Text('No diagnosis results found.'),
        ),
      );
    }

    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        title: const Text(AppStrings.diagnosisResults),
      ),
      body: BlocListener<DiagnosisBloc, DiagnosisState>(
        listener: (context, state) {
          if (state is DiagnosisSaved) {
            Helpers.showSnackBar(context, AppStrings.diagnosisSavedSuccessfully,
                backgroundColor: AppColors.success);
            // Optionally navigate back to dashboard or history after saving
            Navigator.of(context).popUntil(ModalRoute.withName(AppRoutes.dashboard));
          } else if (state is DiagnosisError) {
            Helpers.showSnackBar(context, state.message, backgroundColor: AppColors.error);
          }
        },
        child: Column(
          children: [
            Expanded(
              child: ListView.builder(
                padding: const EdgeInsets.all(AppDimensions.paddingMedium),
                itemCount: results.length,
                itemBuilder: (context, index) {
                  final result = results[index];
                  return _buildResultCard(context, result);
                },
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(AppDimensions.paddingMedium),
              child: BlocBuilder<DiagnosisBloc, DiagnosisState>(
                builder: (context, state) {
                  return CustomButton.icon(
                    text: AppStrings.saveDiagnosis,
                    icon: Icons.save,
                    onPressed: state is DiagnosisLoading
                        ? null
                        : () {
                            context.read<DiagnosisBloc>().add(SaveDiagnosisEvent(results: results));
                          },
                    isLoading: state is DiagnosisLoading, color: null,
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildResultCard(BuildContext context, DiagnosisResult result) {
    Color severityColor;
    switch (result.severity) {
      case Severity.high:
        severityColor = AppColors.error;
        break;
      case Severity.medium:
        severityColor = AppColors.warning;
        break;
      case Severity.low:
      default:
        severityColor = AppColors.success;
        break;
    }

    Color urgencyColor;
    switch (result.urgency) {
      case Urgency.immediate:
        urgencyColor = AppColors.error;
        break;
      case Urgency.soon:
        urgencyColor = AppColors.warning;
        break;
      case Urgency.notUrgent:
      default:
        urgencyColor = AppColors.success;
        break;
    }

    return Card(
      margin: const EdgeInsets.only(bottom: AppDimensions.spaceMedium),
      child: Padding(
        padding: const EdgeInsets.all(AppDimensions.paddingMedium),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              result.name,
              style: Theme.of(context).textTheme.headlineSmall,
            ),
            const SizedBox(height: AppDimensions.spaceSmall),
            Text(
              result.description,
              style: Theme.of(context).textTheme.bodyLarge?.copyWith(color: AppColors.textSecondary),
            ),
            const SizedBox(height: AppDimensions.spaceMedium),
            _buildInfoRow(
              context,
              AppStrings.severity,
              result.severity.toString().split('.').last.toUpperCase(),
              severityColor,
            ),
            const SizedBox(height: AppDimensions.spaceSmall),
            _buildInfoRow(
              context,
              AppStrings.urgency,
              result.urgency.toString().split('.').last.toUpperCase(),
              urgencyColor,
            ),
            const SizedBox(height: AppDimensions.spaceMedium),
            Text(
              AppStrings.causes,
              style: Theme.of(context).textTheme.titleLarge,
            ),
            const SizedBox(height: AppDimensions.spaceSmall),
            ...result.causes.map((cause) => Padding(
                  padding: const EdgeInsets.only(left: AppDimensions.paddingSmall, bottom: AppDimensions.paddingSmall / 2),
                  child: Text('• $cause', style: Theme.of(context).textTheme.bodyMedium),
                )),
            const SizedBox(height: AppDimensions.spaceMedium),
            Text(
              AppStrings.recommendations,
              style: Theme.of(context).textTheme.titleLarge,
            ),
            const SizedBox(height: AppDimensions.spaceSmall),
            ...result.recommendations.map((rec) => Padding(
                  padding: const EdgeInsets.only(left: AppDimensions.paddingSmall, bottom: AppDimensions.paddingSmall / 2),
                  child: Text('• $rec', style: Theme.of(context).textTheme.bodyMedium),
                )),
            const SizedBox(height: AppDimensions.spaceMedium),
            Text(
              'Detected At: ${result.detectedAt.toLocal().toString().split('.')[0]}',
              style: Theme.of(context).textTheme.labelSmall,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildInfoRow(BuildContext context, String label, String value, Color color) {
    return Row(
      children: [
        Text(
          '$label ',
          style: Theme.of(context).textTheme.bodyLarge?.copyWith(fontWeight: FontWeight.w600),
        ),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
          decoration: BoxDecoration(
            color: color.withOpacity(0.15),
            borderRadius: BorderRadius.circular(AppDimensions.borderRadiusSmall),
          ),
          child: Text(
            value,
            style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                  color: color,
                  fontWeight: FontWeight.bold,
                ),
          ),
        ),
      ],
    );
  }
}