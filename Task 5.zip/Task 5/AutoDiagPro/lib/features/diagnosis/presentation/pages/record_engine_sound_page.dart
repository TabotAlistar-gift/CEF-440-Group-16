import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
// import 'package:record/record.dart'; // You would need to add this
import '../../../../config/routes/app_routes.dart';
import '../../../../core/constants/app_colors.dart';
import '../../../../core/constants/app_dimensions.dart';
import '../../../../core/constants/app_strings.dart';
import '../../../../core/utils/helpers.dart';
import '../../../../core/widgets/custom_button.dart';
import '../../../../core/widgets/loading_widget.dart';
import '../bloc/diagnosis_bloc.dart';

class RecordEngineSoundPage extends StatefulWidget {
  const RecordEngineSoundPage({Key? key}) : super(key: key);

  @override
  State<RecordEngineSoundPage> createState() => _RecordEngineSoundPageState();
}

class _RecordEngineSoundPageState extends State<RecordEngineSoundPage> {
  bool _isRecording = false;
  bool _hasRecorded = false;
  String? _recordedSoundPath; // Mock path for recorded sound
  // final _audioRecorder = Record(); // Instance of Record

  @override
  void dispose() {
    // _audioRecorder.dispose(); // Dispose recorder
    super.dispose();
  }

  Future<void> _startRecording() async {
    setState(() {
      _isRecording = true;
      _hasRecorded = false;
      _recordedSoundPath = null;
    });
    Helpers.showToast('Recording started...');
    // In a real app:
    // try {
    //   if (await _audioRecorder.hasPermission()) {
    //     await _audioRecorder.start(
    //       path: 'path/to/save/audio.m4a', // You'd need a real path
    //       encoder: AudioEncoder.AAC,
    //     );
    //     setState(() { _isRecording = true; });
    //   }
    // } catch (e) {
    //   Helpers.showSnackBar(context, 'Failed to start recording: $e', backgroundColor: AppColors.error);
    //   setState(() { _isRecording = false; });
    // }

    // Simulate recording for 3 seconds
    await Future.delayed(const Duration(seconds: 3));
    _stopRecording();
  }

  Future<void> _stopRecording() async {
    setState(() {
      _isRecording = false;
      _hasRecorded = true;
      _recordedSoundPath = 'mock_sound_path.m4a'; // Mock path
    });
    Helpers.showToast('Recording stopped!');
    // In a real app:
    // final path = await _audioRecorder.stop();
    // if (path != null) {
    //   setState(() {
    //     _isRecording = false;
    //     _hasRecorded = true;
    //     _recordedSoundPath = path;
    //   });
    // } else {
    //   Helpers.showSnackBar(context, 'Failed to stop recording.', backgroundColor: AppColors.error);
    // }
  }

  void _analyzeSound() {
    if (_recordedSoundPath != null) {
      context.read<DiagnosisBloc>().add(
            AnalyzeEngineSoundEvent(soundPath: _recordedSoundPath!),
          );
    } else {
      Helpers.showToast('Please record engine sound first.');
    }
  }

  void _resetRecording() {
    setState(() {
      _isRecording = false;
      _hasRecorded = false;
      _recordedSoundPath = null;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        title: const Text(AppStrings.recordEngineSound),
      ),
      body: BlocListener<DiagnosisBloc, DiagnosisState>(
        listener: (context, state) {
          if (state is DiagnosisSuccess) {
            Navigator.of(context).pushNamed(
              AppRoutes.diagnosisResult,
              arguments: state.results,
            );
          } else if (state is DiagnosisError) {
            Helpers.showSnackBar(context, state.message, backgroundColor: AppColors.error);
          }
        },
        child: Padding(
          padding: const EdgeInsets.all(AppDimensions.paddingMedium),
          child: Column(
            children: [
              Expanded(
                child: Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(
                        Icons.mic,
                        size: AppDimensions.iconSizeXLarge * 1.5,
                        color: _isRecording
                            ? AppColors.error
                            : AppColors.textSecondary.withOpacity(0.4),
                      ),
                      const SizedBox(height: AppDimensions.spaceMedium),
                      Text(
                        _isRecording ? 'Recording...' : AppStrings.recordSoundInstructions,
                        textAlign: TextAlign.center,
                        style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                              color: _isRecording ? AppColors.primary : AppColors.textSecondary,
                            ),
                      ),
                      if (_hasRecorded)
                        Padding(
                          padding: const EdgeInsets.only(top: AppDimensions.spaceMedium),
                          child: Text(
                            'Recorded: ${_recordedSoundPath?.split('/').last ?? 'EngineSound.m4a'}',
                            style: Theme.of(context).textTheme.bodyLarge,
                          ),
                        ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: AppDimensions.spaceMedium),
              BlocBuilder<DiagnosisBloc, DiagnosisState>(
                builder: (context, state) {
                  if (state is DiagnosisLoading) {
                    return const LoadingWidget();
                  }
                  return Column(
                    children: [
                      if (!_isRecording && !_hasRecorded)
                        CustomButton.icon(
                          text: 'Start Recording',
                          icon: Icons.mic,
                          color: AppColors.engineSound,
                          onPressed: _startRecording,
                        )
                      else if (_isRecording)
                        CustomButton.icon(
                          text: 'Stop Recording',
                          icon: Icons.stop,
                          color: AppColors.error,
                          onPressed: _stopRecording,
                        )
                      else if (_hasRecorded) ...[
                        CustomButton.icon(
                          text: AppStrings.analyze,
                          icon: Icons.analytics,
                          color: AppColors.engineSound,
                          onPressed: _analyzeSound,
                        ),
                        const SizedBox(height: AppDimensions.spaceSmall),
                        CustomButton.icon(
                          text: AppStrings.reRecordSound,
                          icon: Icons.refresh,
                          color: AppColors.engineSound.withOpacity(0.7),
                          onPressed: _resetRecording,
                        ),
                      ],
                    ],
                  );
                },
              ),
              const SizedBox(height: AppDimensions.spaceMedium),
            ],
          ),
        ),
      ),
    );
  }
}