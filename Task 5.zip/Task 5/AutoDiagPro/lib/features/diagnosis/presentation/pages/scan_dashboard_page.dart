import 'dart:io';
import 'package:car_fault_diagnosis/core/constants/app_dimensions.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:image_picker/image_picker.dart';
import '../../../../config/routes/app_routes.dart';
import '../../../../core/constants/app_colors.dart';
import '../../../../core/constants/app_strings.dart';
import '../../../../core/utils/helpers.dart';
import '../../../../core/widgets/custom_button.dart';
import '../../../../core/widgets/loading_widget.dart';
import '../bloc/diagnosis_bloc.dart';

class ScanDashboardPage extends StatefulWidget {
  const ScanDashboardPage({Key? key}) : super(key: key);

  @override
  State<ScanDashboardPage> createState() => _ScanDashboardPageState();
}

class _ScanDashboardPageState extends State<ScanDashboardPage> {
  File? _image;
  final ImagePicker _picker = ImagePicker();

  Future<void> _pickImage(ImageSource source) async {
    final pickedFile = await _picker.pickImage(source: source);
    setState(() {
      if (pickedFile != null) {
        _image = File(pickedFile.path);
      } else {
        Helpers.showToast('No image selected.');
      }
    });
  }

  void _analyzeImage() {
    if (_image != null) {
      context.read<DiagnosisBloc>().add(
            AnalyzeDashboardLightEvent(imagePath: _image!.path),
          );
    } else {
      Helpers.showToast('Please select an image first.');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        title: const Text(AppStrings.scanDashboardLight),
      ),
      body: BlocListener<DiagnosisBloc, DiagnosisState>(
        listener: (context, state) {
          if (state is DiagnosisSuccess) {
            Navigator.of(context).pushNamed(
              AppRoutes.diagnosisResult,
              arguments: state.results,
            );
          } else if (state is DiagnosisError) {
            Helpers.showSnackBar(context, state.message, backgroundColor: AppColors.error);
          }
        },
        child: Padding(
          padding: const EdgeInsets.all(AppDimensions.paddingMedium),
          child: Column(
            children: [
              Expanded(
                child: Center(
                  child: _image == null
                      ? _buildNoImageSelected()
                      : Image.file(_image!, fit: BoxFit.contain),
                ),
              ),
              const SizedBox(height: AppDimensions.spaceMedium),
              BlocBuilder<DiagnosisBloc, DiagnosisState>(
                builder: (context, state) {
                  if (state is DiagnosisLoading) {
                    return const LoadingWidget();
                  }
                  return Column(
                    children: [
                      if (_image == null) ...[
                        // Use CustomButton.icon here
                        CustomButton.icon(
                          text: 'Take Photo',
                          icon: Icons.camera_alt,
                          color: AppColors.dashboardLight,
                          onPressed: () => _pickImage(ImageSource.camera),
                        ),
                        const SizedBox(height: AppDimensions.spaceSmall),
                        // Use CustomButton.icon here
                        CustomButton.icon(
                          text: 'Choose from Gallery',
                          icon: Icons.photo_library,
                          color: AppColors.dashboardLight,
                          onPressed: () => _pickImage(ImageSource.gallery),
                        ),
                      ] else ...[
                        // Use CustomButton.icon here
                        CustomButton.icon(
                          text: AppStrings.analyze,
                          icon: Icons.search,
                          color: AppColors.dashboardLight,
                          onPressed: _analyzeImage,
                        ),
                        const SizedBox(height: AppDimensions.spaceSmall),
                        // Use CustomButton.icon here
                        CustomButton.icon(
                          text: AppStrings.retakePhoto,
                          icon: Icons.refresh,
                          color: AppColors.dashboardLight.withOpacity(0.7),
                          onPressed: () => setState(() => _image = null),
                        ),
                      ],
                    ],
                  );
                },
              ),
              const SizedBox(height: AppDimensions.spaceMedium),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildNoImageSelected() {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Icon(
          Icons.camera_alt,
          size: AppDimensions.iconSizeXLarge * 1.5,
          color: AppColors.textSecondary.withOpacity(0.4),
        ),
        const SizedBox(height: AppDimensions.spaceMedium),
        Text(
          AppStrings.scanDashboardInstructions,
          textAlign: TextAlign.center,
          style: Theme.of(context).textTheme.headlineSmall?.copyWith(color: AppColors.textSecondary),
        ),
      ],
    );
  }
}

// Remove the extension, it's no longer necessary with the updated CustomButton
// extension CustomButtonWithIcon on CustomButton {
//   CustomButton copyWith({
//     String? text,
//     VoidCallback? onPressed,
//     bool? isLoading,
//     Color? color,
//     Color? textColor,
//     double? width,
//     double? height,
//     EdgeInsetsGeometry? padding,
//     BorderRadiusGeometry? borderRadius,
//     BorderSide? borderSide,
//     TextStyle? textStyle,
//     IconData? icon,
//   }) {
//     return CustomButton(
//       key: key,
//       text: text ?? this.text,
//       onPressed: onPressed ?? this.onPressed,
//       isLoading: isLoading ?? this.isLoading,
//       color: color ?? this.color,
//       textColor: textColor ?? this.textColor,
//       width: width ?? this.width,
//       height: height ?? this.height,
//       padding: padding ?? this.padding,
//       borderRadius: borderRadius ?? this.borderRadius,
//       borderSide: borderSide ?? this.borderSide,
//       textStyle: textStyle ?? this.textStyle,
//       icon: icon, // Pass the icon directly
//     );
//   }
// }