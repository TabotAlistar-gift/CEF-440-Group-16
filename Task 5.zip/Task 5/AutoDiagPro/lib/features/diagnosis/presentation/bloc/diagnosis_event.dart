part of 'diagnosis_bloc.dart';

abstract class DiagnosisEvent extends Equatable {
  const DiagnosisEvent();

  @override
  List<Object> get props => [];
}

class AnalyzeDashboardLightEvent extends DiagnosisEvent {
  final String imagePath;

  const AnalyzeDashboardLightEvent({required this.imagePath});

  @override
  List<Object> get props => [imagePath];
}

class AnalyzeEngineSoundEvent extends DiagnosisEvent {
  final String soundPath;

  const AnalyzeEngineSoundEvent({required this.soundPath});

  @override
  List<Object> get props => [soundPath];
}

class SaveDiagnosisEvent extends DiagnosisEvent {
  final List<DiagnosisResult> results;

  const SaveDiagnosisEvent({required this.results});

  @override
  List<Object> get props => [results];
}