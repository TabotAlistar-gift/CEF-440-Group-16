part of 'diagnosis_bloc.dart';

abstract class DiagnosisState extends Equatable {
  const DiagnosisState();

  @override
  List<Object> get props => [];
}

class DiagnosisInitial extends DiagnosisState {}

class DiagnosisLoading extends DiagnosisState {}

class DiagnosisSuccess extends DiagnosisState {
  final List<DiagnosisResult> results;

  const DiagnosisSuccess({required this.results});

  @override
  List<Object> get props => [results];
}

class DiagnosisSaved extends DiagnosisState {}

class DiagnosisError extends DiagnosisState {
  final String message;

  const DiagnosisError({required this.message});

  @override
  List<Object> get props => [message];
}