import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:equatable/equatable.dart';
// Import dartz
import '../../../../core/errors/failures.dart';
import '../../domain/entities/diagnosis_result.dart';
import '../../domain/usecases/analyze_dashboard_light_usecase.dart';
import '../../domain/usecases/analyze_engine_sound_usecase.dart';
import '../../domain/usecases/save_diagnosis_usecase.dart';

part 'diagnosis_event.dart';
part 'diagnosis_state.dart';

class DiagnosisBloc extends Bloc<DiagnosisEvent, DiagnosisState> {
  final AnalyzeDashboardLightUseCase analyzeDashboardLightUseCase;
  final AnalyzeEngineSoundUseCase analyzeEngineSoundUseCase;
  final SaveDiagnosisUseCase saveDiagnosisUseCase;

  DiagnosisBloc({
    required this.analyzeDashboardLightUseCase,
    required this.analyzeEngineSoundUseCase,
    required this.saveDiagnosisUseCase,
  }) : super(DiagnosisInitial()) {
    on<AnalyzeDashboardLightEvent>(_onAnalyzeDashboardLight);
    on<AnalyzeEngineSoundEvent>(_onAnalyzeEngineSound);
    on<SaveDiagnosisEvent>(_onSaveDiagnosis);
  }

  Future<void> _onAnalyzeDashboardLight(
    AnalyzeDashboardLightEvent event,
    Emitter<DiagnosisState> emit,
  ) async {
    emit(DiagnosisLoading());
    final result = await analyzeDashboardLightUseCase(AnalyzeLightParams(imagePath: event.imagePath));
    result.fold(
      (failure) => emit(DiagnosisError(message: _mapFailureToMessage(failure))),
      (results) => emit(DiagnosisSuccess(results: results)),
    );
  }

  Future<void> _onAnalyzeEngineSound(
    AnalyzeEngineSoundEvent event,
    Emitter<DiagnosisState> emit,
  ) async {
    emit(DiagnosisLoading());
    final result = await analyzeEngineSoundUseCase(AnalyzeSoundParams(soundPath: event.soundPath));
    result.fold(
      (failure) => emit(DiagnosisError(message: _mapFailureToMessage(failure))),
      (results) => emit(DiagnosisSuccess(results: results)),
    );
  }

  Future<void> _onSaveDiagnosis(
    SaveDiagnosisEvent event,
    Emitter<DiagnosisState> emit,
  ) async {
    // Optionally emit Loading state if saving takes time and you want a visual indicator
    // emit(DiagnosisLoading());
    final result = await saveDiagnosisUseCase(SaveDiagnosisParams(results: event.results));
    result.fold(
      (failure) => emit(DiagnosisError(message: _mapFailureToMessage(failure))),
      (_) => emit(DiagnosisSaved()),
    );
  }

  String _mapFailureToMessage(Failure failure) {
    switch (failure.runtimeType) {
      case ServerFailure:
        return (failure as ServerFailure).message;
      case NetworkFailure:
        return 'Please check your internet connection.';
      default:
        return 'An unexpected error occurred.';
    }
  }
}