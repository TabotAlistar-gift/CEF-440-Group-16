import '../../../../core/errors/exceptions.dart';
import '../../../../core/network/api_client.dart';
import '../models/diagnosis_result_model.dart';

abstract class DiagnosisRemoteDataSource {
  Future<List<DiagnosisResultModel>> analyzeDashboardLight(String imagePath);
  Future<List<DiagnosisResultModel>> analyzeEngineSound(String soundPath);
  Future<void> saveDiagnosis(List<DiagnosisResultModel> results);
}

class DiagnosisRemoteDataSourceImpl implements DiagnosisRemoteDataSource {
  final ApiClient apiClient;

  DiagnosisRemoteDataSourceImpl({required this.apiClient});

  @override
  Future<List<DiagnosisResultModel>> analyzeDashboardLight(String imagePath) async {
    try {
      // Simulate API call
      await Future.delayed(const Duration(seconds: 2));

      // Mock data, in a real app, this would be from API
      final mockResponse = [
        {
          'id': '1',
          'name': 'Engine Temperature Warning',
          'description': 'Engine is running hotter than normal operating temperature',
          'severity': 'high',
          'urgency': 'immediate',
          'causes': ['Low coolant level', 'Faulty thermostat'],
          'recommendations': ['Stop driving immediately', 'Check coolant level'],
          'detectedAt': DateTime.now().toIso8601String(),
          'imagePath': imagePath,
        },
      ];
      return mockResponse.map((json) => DiagnosisResultModel.fromJson(json)).toList();
    } catch (e) {
      throw ServerException(message: 'Failed to analyze image: $e');
    }
  }

  @override
  Future<List<DiagnosisResultModel>> analyzeEngineSound(String soundPath) async {
    try {
      // Simulate API call
      await Future.delayed(const Duration(seconds: 2));

      // Mock data
      final mockResponse = [
        {
          'id': '2',
          'name': 'Engine Knocking Sound',
          'description': 'Abnormal knocking sound detected from engine',
          'severity': 'medium',
          'urgency': 'soon',
          'causes': ['Low octane fuel', 'Carbon buildup'],
          'recommendations': ['Use higher octane fuel', 'Schedule engine inspection'],
          'detectedAt': DateTime.now().toIso8601String(),
          'soundPath': soundPath,
        },
      ];
      return mockResponse.map((json) => DiagnosisResultModel.fromJson(json)).toList();
    } catch (e) {
      throw ServerException(message: 'Failed to analyze sound: $e');
    }
  }

  @override
  Future<void> saveDiagnosis(List<DiagnosisResultModel> results) async {
    try {
      // Simulate API call to save diagnosis results
      await Future.delayed(const Duration(seconds: 1));
      // final data = results.map((e) => e.toJson()).toList();
      // await apiClient.post(Endpoints.saveDiagnosis, body: {'results': data});
      print('Diagnosis results saved: ${results.length} items');
    } catch (e) {
      throw ServerException(message: 'Failed to save diagnosis: $e');
    }
  }
}