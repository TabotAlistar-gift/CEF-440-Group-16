import 'package:dartz/dartz.dart';
import '../../../../core/errors/exceptions.dart';
import '../../../../core/errors/failures.dart';
import '../../domain/entities/diagnosis_result.dart';
import '../../domain/repositories/diagnosis_repository.dart';
import '../datasources/diagnosis_remote_data_source.dart';
import '../models/diagnosis_result_model.dart';

class DiagnosisRepositoryImpl implements DiagnosisRepository {
  final DiagnosisRemoteDataSource remoteDataSource;

  DiagnosisRepositoryImpl({required this.remoteDataSource});

  @override
  Future<Either<Failure, List<DiagnosisResult>>> analyzeDashboardLight(String imagePath) async {
    try {
      final resultModels = await remoteDataSource.analyzeDashboardLight(imagePath);
      return Right(resultModels);
    } on ServerException catch (e) {
      return Left(ServerFailure(e.message));
    } on NetworkException catch (e) {
      return Left(NetworkFailure(e.message));
    } catch (e) {
      return Left(ServerFailure('An unexpected error occurred: ${e.toString()}'));
    }
  }

  @override
  Future<Either<Failure, List<DiagnosisResult>>> analyzeEngineSound(String soundPath) async {
    try {
      final resultModels = await remoteDataSource.analyzeEngineSound(soundPath);
      return Right(resultModels);
    } on ServerException catch (e) {
      return Left(ServerFailure(e.message));
    } on NetworkException catch (e) {
      return Left(NetworkFailure(e.message));
    } catch (e) {
      return Left(ServerFailure('An unexpected error occurred: ${e.toString()}'));
    }
  }

  @override
  Future<Either<Failure, void>> saveDiagnosis(List<DiagnosisResult> results) async {
    try {
      final resultModels = results.map((e) => DiagnosisResultModel.fromEntity(e)).toList();
      await remoteDataSource.saveDiagnosis(resultModels);
      return const Right(null);
    } on ServerException catch (e) {
      return Left(ServerFailure(e.message));
    } on NetworkException catch (e) {
      return Left(NetworkFailure(e.message));
    } catch (e) {
      return Left(ServerFailure('An unexpected error occurred: ${e.toString()}'));
    }
  }
}