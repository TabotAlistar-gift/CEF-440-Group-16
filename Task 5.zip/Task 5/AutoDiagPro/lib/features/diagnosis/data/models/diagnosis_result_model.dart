import '../../domain/entities/diagnosis_result.dart';

class DiagnosisResultModel extends DiagnosisResult {
  const DiagnosisResultModel({
    required String id,
    required String name,
    required String description,
    required Severity severity,
    required Urgency urgency,
    required List<String> causes,
    required List<String> recommendations,
    required DateTime detectedAt,
    String? imagePath,
    String? soundPath,
  }) : super(
          id: id,
          name: name,
          description: description,
          severity: severity,
          urgency: urgency,
          causes: causes,
          recommendations: recommendations,
          detectedAt: detectedAt,
          imagePath: imagePath,
          soundPath: soundPath,
        );

  factory DiagnosisResultModel.fromJson(Map<String, dynamic> json) {
    return DiagnosisResultModel(
      id: json['id'],
      name: json['name'],
      description: json['description'],
      severity: Severity.values.firstWhere(
        (e) => e.toString().split('.').last == json['severity'],
        orElse: () => Severity.low,
      ),
      urgency: Urgency.values.firstWhere(
        (e) => e.toString().split('.').last == json['urgency'],
        orElse: () => Urgency.notUrgent,
      ),
      causes: List<String>.from(json['causes']),
      recommendations: List<String>.from(json['recommendations']),
      detectedAt: DateTime.parse(json['detectedAt']),
      imagePath: json['imagePath'],
      soundPath: json['soundPath'],
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'name': name,
      'description': description,
      'severity': severity.toString().split('.').last,
      'urgency': urgency.toString().split('.').last,
      'causes': causes,
      'recommendations': recommendations,
      'detectedAt': detectedAt.toIso8601String(),
      'imagePath': imagePath,
      'soundPath': soundPath,
    };
  }

  factory DiagnosisResultModel.fromEntity(DiagnosisResult result) {
    return DiagnosisResultModel(
      id: result.id,
      name: result.name,
      description: result.description,
      severity: result.severity,
      urgency: result.urgency,
      causes: result.causes,
      recommendations: result.recommendations,
      detectedAt: result.detectedAt,
      imagePath: result.imagePath,
      soundPath: result.soundPath,
    );
  }
}