import 'package:dartz/dartz.dart';
import '../../../../core/errors/failures.dart';
import '../../../../core/usecases/usecase.dart';
import '../entities/diagnosis_result.dart';
import '../repositories/diagnosis_repository.dart';

class AnalyzeDashboardLightUseCase implements UseCase<List<DiagnosisResult>, AnalyzeLightParams> {
  final DiagnosisRepository repository;

  AnalyzeDashboardLightUseCase(this.repository);

  @override
  Future<Either<Failure, List<DiagnosisResult>>> call(AnalyzeLightParams params) async {
    return await repository.analyzeDashboardLight(params.imagePath);
  }
}

class AnalyzeLightParams {
  final String imagePath;

  AnalyzeLightParams({required this.imagePath});
}