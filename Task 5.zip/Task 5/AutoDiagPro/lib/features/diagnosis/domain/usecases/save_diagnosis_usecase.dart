import 'package:dartz/dartz.dart';
import '../../../../core/errors/failures.dart';
import '../../../../core/usecases/usecase.dart';
import '../entities/diagnosis_result.dart';
import '../repositories/diagnosis_repository.dart';

class SaveDiagnosisUseCase implements UseCase<void, SaveDiagnosisParams> {
  final DiagnosisRepository repository;

  SaveDiagnosisUseCase(this.repository);

  @override
  Future<Either<Failure, void>> call(SaveDiagnosisParams params) async {
    return await repository.saveDiagnosis(params.results);
  }
}

class SaveDiagnosisParams {
  final List<DiagnosisResult> results;

  SaveDiagnosisParams({required this.results});
}