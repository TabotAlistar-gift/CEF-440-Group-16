import 'package:dartz/dartz.dart';
import '../../../../core/errors/failures.dart';
import '../../../../core/usecases/usecase.dart';
import '../entities/diagnosis_result.dart';
import '../repositories/diagnosis_repository.dart';

class AnalyzeEngineSoundUseCase implements UseCase<List<DiagnosisResult>, AnalyzeSoundParams> {
  final DiagnosisRepository repository;

  AnalyzeEngineSoundUseCase(this.repository);

  @override
  Future<Either<Failure, List<DiagnosisResult>>> call(AnalyzeSoundParams params) async {
    return await repository.analyzeEngineSound(params.soundPath);
  }
}

class AnalyzeSoundParams {
  final String soundPath;

  AnalyzeSoundParams({required this.soundPath});
}