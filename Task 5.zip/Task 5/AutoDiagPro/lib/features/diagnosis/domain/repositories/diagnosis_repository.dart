import 'package:dartz/dartz.dart';
import '../../../../core/errors/failures.dart';
import '../entities/diagnosis_result.dart';

abstract class DiagnosisRepository {
  Future<Either<Failure, List<DiagnosisResult>>> analyzeDashboardLight(String imagePath);
  Future<Either<Failure, List<DiagnosisResult>>> analyzeEngineSound(String soundPath);
  Future<Either<Failure, void>> saveDiagnosis(List<DiagnosisResult> results);
}