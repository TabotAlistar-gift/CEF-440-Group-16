import 'package:car_fault_diagnosis/features/auth/domain/entities/user.dart';

import '../../../../core/errors/exceptions.dart';
import '../../../../core/network/api_client.dart';
import '../models/user_model.dart';

abstract class AuthRemoteDataSource {
  Future<UserModel> login(String email, String password);
  Future<UserModel> register(String name, String email, String password, UserType userType);
  Future<void> logout();
  Future<UserModel?> checkAuthStatus(); // Simulate checking if a user is logged in
}

class AuthRemoteDataSourceImpl implements AuthRemoteDataSource {
  final ApiClient apiClient;

  AuthRemoteDataSourceImpl({required this.apiClient});

  @override
  Future<UserModel> login(String email, String password) async {
    try {
      // Simulate network delay
      await Future.delayed(const Duration(seconds: 1));

      // Mock API response
      if (email == 'test@example.com' && password == 'password123') {
        final Map<String, dynamic> response = {
          'id': 'user123',
          'name': 'Test User',
          'email': email,
          'userType': 'carOwner',
          'createdAt': DateTime.now().toIso8601String(),
        };
        return UserModel.fromJson(response);
      } else if (email == 'mechanic@example.com' && password == 'password123') {
        final Map<String, dynamic> response = {
          'id': 'mech456',
          'name': 'Test Mechanic',
          'email': email,
          'userType': 'mechanic',
          'createdAt': DateTime.now().toIso8601String(),
        };
        return UserModel.fromJson(response);
      } else {
        throw AuthException(message: 'Invalid credentials');
      }
    } on AuthException {
      rethrow;
    } catch (e) {
      throw ServerException(message: 'Failed to login: $e');
    }
  }

  @override
  Future<UserModel> register(String name, String email, String password, UserType userType) async {
    try {
      // Simulate network delay
      await Future.delayed(const Duration(seconds: 1));

      // Mock successful registration
      final Map<String, dynamic> response = {
        'id': 'newuser_${DateTime.now().millisecondsSinceEpoch}',
        'name': name,
        'email': email,
        'userType': userType.toString().split('.').last,
        'createdAt': DateTime.now().toIso8601String(),
      };
      return UserModel.fromJson(response);
    } catch (e) {
      throw ServerException(message: 'Failed to register: $e');
    }
  }

  @override
  Future<void> logout() async {
    try {
      // Simulate network delay
      await Future.delayed(const Duration(milliseconds: 500));
      // In a real app, this would clear tokens/sessions
    } catch (e) {
      throw ServerException(message: 'Failed to logout: $e');
    }
  }

  @override
  Future<UserModel?> checkAuthStatus() async {
    try {
      // Simulate network delay or shared preferences check
      await Future.delayed(const Duration(milliseconds: 500));
      // For now, always return null (not logged in) or a mock user if you want
      // For persistent login, you'd load from local storage here
      // Example:
      // String? storedUserJson = await _localStorage.getUser();
      // if (storedUserJson != null) {
      //   return UserModel.fromJson(json.decode(storedUserJson));
      // }
      return null; // Not logged in
    } catch (e) {
      throw ServerException(message: 'Failed to check auth status: $e');
    }
  }
}