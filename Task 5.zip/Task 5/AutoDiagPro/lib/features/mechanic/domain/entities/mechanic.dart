import 'package:equatable/equatable.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
// Ensure Maps_flutter is imported

class Mechanic extends Equatable {
  final String id;
  final String name;
  final LatLng location;
  final double rating;
  final int reviews;
  final double distance;
  final List<String> specializations;
  final String phoneNumber;
  final bool isOpen;

  const Mechanic({
    required this.id,
    required this.name,
    required this.location,
    required this.rating,
    required this.reviews,
    required this.distance,
    required this.specializations,
    required this.phoneNumber,
    required this.isOpen,
  });

  @override
  List<Object?> get props => [
        id,
        name,
        location,
        rating,
        reviews,
        distance,
        specializations,
        phoneNumber,
        isOpen,
      ];
}