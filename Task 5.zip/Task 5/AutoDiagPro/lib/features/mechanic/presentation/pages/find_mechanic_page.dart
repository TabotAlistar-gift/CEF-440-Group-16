import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:url_launcher/url_launcher.dart'; // For making calls
import '../../../../core/constants/app_colors.dart';
import '../../../../core/constants/app_dimensions.dart';
import '../../../../core/constants/app_strings.dart';
import '../../../../core/utils/helpers.dart';
import '../../../../core/widgets/custom_button.dart';
import '../../domain/entities/mechanic.dart';

class FindMechanicPage extends StatefulWidget {
  const FindMechanicPage({Key? key}) : super(key: key);

  @override
  State<FindMechanicPage> createState() => _FindMechanicPageState();
}

class _FindMechanicPageState extends State<FindMechanicPage> {
  GoogleMapController? _mapController;
  Set<Marker> _markers = {};
  final LatLng _defaultLocation = const LatLng(4.0511, 9.7679); // Limbe, Cameroon

  // Mock data
  final List<Mechanic> _mechanics = [
    const Mechanic(
      id: '1',
      name: 'AutoFix Garage',
      location: LatLng(4.0511, 9.7679),
      rating: 4.5,
      reviews: 124,
      distance: 0.5,
      specializations: ['Engine Repair', 'Electrical', 'AC Repair'],
      phoneNumber: '+237678123456',
      isOpen: true,
    ),
    const Mechanic(
      id: '2',
      name: 'Quick Service Center',
      location: LatLng(4.0550, 9.7700),
      rating: 4.2,
      reviews: 89,
      distance: 1.2,
      specializations: ['Oil Change', 'Brake Service', 'Tire Service'],
      phoneNumber: '+237678234567',
      isOpen: true,
    ),
    const Mechanic(
      id: '3',
      name: 'Expert Auto Repair',
      location: LatLng(4.0480, 9.7650),
      rating: 4.8,
      reviews: 201,
      distance: 2.3,
      specializations: ['Engine Diagnostics', 'Transmission', 'Suspension'],
      phoneNumber: '+237678345678',
      isOpen: false,
    ),
    const Mechanic(
      id: '4',
      name: 'Local Mechanic John',
      location: LatLng(4.0600, 9.7750),
      rating: 3.9,
      reviews: 55,
      distance: 3.1,
      specializations: ['Tire Repair', 'Battery Service'],
      phoneNumber: '+237678456789',
      isOpen: true,
    ),
  ];

  @override
  void initState() {
    super.initState();
    _loadMarkers();
  }

  void _loadMarkers() {
    setState(() {
      _markers = _mechanics.map((mechanic) {
        return Marker(
          markerId: MarkerId(mechanic.id),
          position: mechanic.location,
          infoWindow: InfoWindow(
            title: mechanic.name,
            snippet: '${mechanic.rating} ⭐ (${mechanic.reviews} reviews)',
            onTap: () => _showMechanicDetails(mechanic),
          ),
          icon: BitmapDescriptor.defaultMarkerWithHue(
            mechanic.isOpen
                ? BitmapDescriptor.hueGreen
                : BitmapDescriptor.hueRed,
          ),
          onTap: () {
            _showMechanicDetails(mechanic);
          },
        );
      }).toSet();
    });
  }

  void _showMechanicDetails(Mechanic mechanic) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true, // Allow content to expand
      builder: (context) => _MechanicDetailsSheet(mechanic: mechanic),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        title: const Text(AppStrings.findMechanic),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.filter_list, color: Colors.white),
            onPressed: () {
              // Show filter options - implement later
              Helpers.showToast('Filter options coming soon!');
            },
          ),
        ],
      ),
      body: Stack(
        children: [
          // Map
          GoogleMap(
            initialCameraPosition: CameraPosition(
              target: _defaultLocation,
              zoom: 14,
            ),
            markers: _markers,
            myLocationEnabled: true,
            myLocationButtonEnabled: false,
            onMapCreated: (controller) {
              _mapController = controller;
            },
          ),

          // Search Bar
          Positioned(
            top: AppDimensions.paddingMedium,
            left: AppDimensions.paddingMedium,
            right: AppDimensions.paddingMedium,
            child: Container(
              decoration: BoxDecoration(
                color: AppColors.surface,
                borderRadius: BorderRadius.circular(AppDimensions.borderRadiusLarge),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.1),
                    blurRadius: 10,
                    offset: const Offset(0, 2),
                  ),
                ],
              ),
              child: TextField(
                decoration: const InputDecoration(
                  hintText: AppStrings.searchMechanics,
                  prefixIcon: Icon(Icons.search, color: AppColors.textSecondary),
                  border: InputBorder.none,
                  contentPadding: EdgeInsets.symmetric(
                    horizontal: AppDimensions.paddingMedium,
                    vertical: AppDimensions.paddingSmall,
                  ),
                ),
                onTap: () {
                  // Implement search logic or navigate to a search page
                  Helpers.showToast('Search functionality coming soon!');
                },
              ),
            ),
          ),

          // My Location Button
          Positioned(
            bottom: AppDimensions.paddingLarge + 80, // Adjust based on sheet size
            right: AppDimensions.paddingMedium,
            child: FloatingActionButton(
              mini: true,
              backgroundColor: AppColors.surface,
              onPressed: () {
                // Center on user location - requires location permission
                Helpers.showToast('Centering on current location (requires permission).');
                _mapController?.animateCamera(
                  CameraUpdate.newLatLngZoom(_defaultLocation, 14), // Using default for now
                );
              },
              child: const Icon(
                Icons.my_location,
                color: AppColors.primary,
              ),
            ),
          ),

          // Mechanics List Draggable Sheet
          DraggableScrollableSheet(
            initialChildSize: 0.3,
            minChildSize: 0.1,
            maxChildSize: 0.9,
            builder: (context, scrollController) {
              return Container(
                decoration: const BoxDecoration(
                  color: AppColors.surface,
                  borderRadius: BorderRadius.only(
                    topLeft: Radius.circular(AppDimensions.borderRadiusExtraLarge),
                    topRight: Radius.circular(AppDimensions.borderRadiusExtraLarge),
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black12,
                      blurRadius: 10,
                      spreadRadius: 2,
                    ),
                  ],
                ),
                child: Column(
                  children: [
                    // Handle
                    Container(
                      width: 40,
                      height: 4,
                      margin: const EdgeInsets.symmetric(vertical: AppDimensions.spaceSmall),
                      decoration: BoxDecoration(
                        color: AppColors.divider,
                        borderRadius: BorderRadius.circular(2),
                      ),
                    ),

                    // Title and Sort
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: AppDimensions.paddingMedium),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(
                            '${AppStrings.nearbyMechanics} (${_mechanics.length})',
                            style: Theme.of(context).textTheme.headlineSmall,
                          ),
                          TextButton(
                            onPressed: () {
                              // Sort options - implement later
                              Helpers.showToast('Sort options coming soon!');
                            },
                            child: const Text(AppStrings.sort),
                          ),
                        ],
                      ),
                    ),

                    // List of Mechanics
                    Expanded(
                      child: ListView.builder(
                        controller: scrollController,
                        padding: const EdgeInsets.all(AppDimensions.paddingMedium),
                        itemCount: _mechanics.length,
                        itemBuilder: (context, index) {
                          final mechanic = _mechanics[index];
                          return _MechanicCard(
                            mechanic: mechanic,
                            onTap: () => _showMechanicDetails(mechanic),
                          );
                        },
                      ),
                    ),
                  ],
                ),
              );
            },
          ),
        ],
      ),
    );
  }
}

class _MechanicCard extends StatelessWidget {
  final Mechanic mechanic;
  final VoidCallback onTap;

  const _MechanicCard({
    Key? key,
    required this.mechanic,
    required this.onTap,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: AppDimensions.spaceMedium),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(AppDimensions.borderRadiusLarge),
        border: Border.all(color: AppColors.divider),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.03),
            blurRadius: 5,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Material(
        color: Colors.transparent,
        borderRadius: BorderRadius.circular(AppDimensions.borderRadiusLarge),
        child: InkWell(
          borderRadius: BorderRadius.circular(AppDimensions.borderRadiusLarge),
          onTap: onTap,
          child: Padding(
            padding: const EdgeInsets.all(AppDimensions.paddingMedium),
            child: Row(
              children: [
                // Avatar
                CircleAvatar(
                  radius: 30,
                  backgroundColor: AppColors.primary.withOpacity(0.1),
                  child: const Icon(
                    Icons.build,
                    color: AppColors.primary,
                    size: AppDimensions.iconSizeLarge,
                  ),
                ),
                const SizedBox(width: AppDimensions.spaceMedium),

                // Info
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Expanded(
                            child: Text(
                              mechanic.name,
                              style: Theme.of(context).textTheme.headlineSmall,
                            ),
                          ),
                          Container(
                            padding: const EdgeInsets.symmetric(
                              horizontal: AppDimensions.paddingSmall,
                              vertical: AppDimensions.paddingSmall / 2,
                            ),
                            decoration: BoxDecoration(
                              color: mechanic.isOpen
                                  ? AppColors.success.withOpacity(0.1)
                                  : AppColors.error.withOpacity(0.1),
                              borderRadius: BorderRadius.circular(AppDimensions.borderRadiusLarge),
                            ),
                            child: Text(
                              mechanic.isOpen ? 'Open' : 'Closed',
                              style: Theme.of(context).textTheme.labelSmall?.copyWith(
                                    fontWeight: FontWeight.w600,
                                    color: mechanic.isOpen ? AppColors.success : AppColors.error,
                                  ),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: AppDimensions.spaceSmall / 2),
                      Row(
                        children: [
                          const Icon(
                            Icons.star,
                            size: AppDimensions.iconSizeSmall,
                            color: AppColors.warning,
                          ),
                          const SizedBox(width: AppDimensions.spaceSmall / 2),
                          Text(
                            '${mechanic.rating}',
                            style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                                  fontWeight: FontWeight.w500,
                                  color: AppColors.textPrimary,
                                ),
                          ),
                          const SizedBox(width: AppDimensions.spaceSmall / 2),
                          Text(
                            '(${mechanic.reviews} ${AppStrings.reviews})',
                            style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                                  color: AppColors.textSecondary,
                                ),
                          ),
                          const SizedBox(width: AppDimensions.spaceMedium),
                          const Icon(
                            Icons.location_on,
                            size: AppDimensions.iconSizeSmall,
                            color: AppColors.textSecondary,
                          ),
                          const SizedBox(width: AppDimensions.spaceSmall / 2),
                          Text(
                            '${mechanic.distance} km',
                            style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                                  color: AppColors.textSecondary,
                                ),
                          ),
                        ],
                      ),
                      const SizedBox(height: AppDimensions.spaceSmall),
                      Wrap(
                        spacing: AppDimensions.spaceSmall,
                        runSpacing: AppDimensions.spaceSmall / 2,
                        children: mechanic.specializations
                            .take(3) // Limit to a few for card view
                            .map((spec) => Container(
                                  padding: const EdgeInsets.symmetric(
                                    horizontal: AppDimensions.paddingSmall,
                                    vertical: AppDimensions.paddingSmall / 2,
                                  ),
                                  decoration: BoxDecoration(
                                    color: AppColors.primary.withOpacity(0.08),
                                    borderRadius: BorderRadius.circular(AppDimensions.borderRadiusSmall),
                                  ),
                                  child: Text(
                                    spec,
                                    style: Theme.of(context).textTheme.labelSmall?.copyWith(
                                          color: AppColors.primaryDark,
                                          fontWeight: FontWeight.w500,
                                        ),
                                  ),
                                ))
                            .toList(),
                      ),
                    ],
                  ),
                ),
                const Icon(
                  Icons.chevron_right,
                  color: AppColors.textSecondary,
                  size: AppDimensions.iconSizeMedium,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _MechanicDetailsSheet extends StatelessWidget {
  final Mechanic mechanic;

  const _MechanicDetailsSheet({Key? key, required this.mechanic}) : super(key: key);

  Future<void> _makeCall(String phoneNumber) async {
    final Uri launchUri = Uri(
      scheme: 'tel',
      path: phoneNumber,
    );
    if (await canLaunchUrl(launchUri)) {
      await launchUrl(launchUri);
    } else {
      Helpers.showToast('Could not launch phone dialer.');
    }
  }

  Future<void> _getDirections(LatLng destination) async {
    final String googleMapsUrl =
        'https://www.google.com/maps/dir/?api=1&destination=${destination.latitude},${destination.longitude}&travelmode=driving';
    final Uri launchUri = Uri.parse(googleMapsUrl);
    if (await canLaunchUrl(launchUri)) {
      await launchUrl(launchUri);
    } else {
      Helpers.showToast('Could not launch Google Maps.');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(
        color: AppColors.background,
        borderRadius: BorderRadius.only(
          topLeft: Radius.circular(AppDimensions.borderRadiusExtraLarge),
          topRight: Radius.circular(AppDimensions.borderRadiusExtraLarge),
        ),
      ),
      padding: const EdgeInsets.all(AppDimensions.paddingLarge),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Handle
          Center(
            child: Container(
              width: 60,
              height: 5,
              decoration: BoxDecoration(
                color: AppColors.divider,
                borderRadius: BorderRadius.circular(AppDimensions.borderRadiusSmall),
              ),
              margin: const EdgeInsets.only(bottom: AppDimensions.spaceMedium),
            ),
          ),
          Text(
            mechanic.name,
            style: Theme.of(context).textTheme.displayMedium,
          ),
          const SizedBox(height: AppDimensions.spaceSmall),
          Row(
            children: [
              const Icon(Icons.star, color: AppColors.warning, size: AppDimensions.iconSizeMedium),
              const SizedBox(width: AppDimensions.spaceSmall / 2),
              Text(
                '${mechanic.rating} (${mechanic.reviews} ${AppStrings.reviews})',
                style: Theme.of(context).textTheme.bodyLarge,
              ),
              const SizedBox(width: AppDimensions.spaceMedium),
              const Icon(Icons.location_on, color: AppColors.textSecondary, size: AppDimensions.iconSizeMedium),
              const SizedBox(width: AppDimensions.spaceSmall / 2),
              Text(
                '${mechanic.distance} km',
                style: Theme.of(context).textTheme.bodyLarge,
              ),
            ],
          ),
          const SizedBox(height: AppDimensions.spaceMedium),
          Text(
            AppStrings.specializations,
            style: Theme.of(context).textTheme.titleLarge,
          ),
          const SizedBox(height: AppDimensions.spaceSmall),
          Wrap(
            spacing: AppDimensions.spaceSmall,
            runSpacing: AppDimensions.spaceSmall / 2,
            children: mechanic.specializations
                .map((spec) => Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: AppDimensions.paddingSmall,
                        vertical: AppDimensions.paddingSmall / 2,
                      ),
                      decoration: BoxDecoration(
                        color: AppColors.primary.withOpacity(0.1),
                        borderRadius: BorderRadius.circular(AppDimensions.borderRadiusSmall),
                      ),
                      child: Text(
                        spec,
                        style: Theme.of(context).textTheme.labelLarge?.copyWith(
                              color: AppColors.primary,
                            ),
                      ),
                    ))
                .toList(),
          ),
          const SizedBox(height: AppDimensions.spaceLarge),
          CustomButton.icon(
            text: AppStrings.callMechanic,
            icon: Icons.call,
            onPressed: () => _makeCall(mechanic.phoneNumber),
            color: AppColors.secondary,
          ),
          const SizedBox(height: AppDimensions.spaceMedium),
          CustomButton.icon(
            text: AppStrings.getDirections,
            icon: Icons.directions,
            onPressed: () => _getDirections(mechanic.location),
            color: AppColors.info,
          ),
          const SizedBox(height: AppDimensions.spaceLarge),
        ],
      ),
    );
  }
}