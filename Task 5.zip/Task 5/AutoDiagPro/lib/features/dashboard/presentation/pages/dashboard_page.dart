import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../../../../config/routes/app_routes.dart';
import '../../../../core/constants/app_colors.dart';
import '../../../../core/constants/app_dimensions.dart';
import '../../../../core/constants/app_strings.dart';
import '../../../../core/utils/helpers.dart';
import '../../../auth/presentation/bloc/auth_bloc.dart';
import '../widgets/dashboard_menu_item.dart';

class DashboardPage extends StatelessWidget {
  const DashboardPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        title: const Text(AppStrings.dashboardTitle),
        actions: [
          IconButton(
            icon: const Icon(Icons.person, color: Colors.white),
            onPressed: () {
              Navigator.of(context).pushNamed(AppRoutes.profile);
            },
          ),
          IconButton(
            icon: const Icon(Icons.settings, color: Colors.white),
            onPressed: () {
              Navigator.of(context).pushNamed(AppRoutes.settings);
            },
          ),
          BlocListener<AuthBloc, AuthState>(
            listener: (context, state) {
              if (state is AuthInitial) {
                // User logged out
                Navigator.of(context).pushReplacementNamed(AppRoutes.login);
                Helpers.showSnackBar(context, 'Logged out successfully!', backgroundColor: AppColors.info);
              } else if (state is AuthError) {
                Helpers.showSnackBar(context, state.message, backgroundColor: AppColors.error);
              }
            },
            child: IconButton(
              icon: const Icon(Icons.logout, color: Colors.white),
              onPressed: () {
                context.read<AuthBloc>().add(LogoutEvent());
              },
            ),
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(AppDimensions.paddingMedium),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            BlocBuilder<AuthBloc, AuthState>(
              builder: (context, state) {
                String userName = 'User';
                if (state is AuthSuccess) {
                  userName = state.user.name.split(' ').first;
                }
                return Text(
                  '${Helpers.getGreeting()}, $userName!',
                  style: Theme.of(context).textTheme.displayLarge?.copyWith(
                        color: AppColors.textPrimary,
                      ),
                );
              },
            ),
            const SizedBox(height: AppDimensions.spaceLarge),
            GridView.count(
              crossAxisCount: 2,
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              mainAxisSpacing: AppDimensions.spaceMedium,
              crossAxisSpacing: AppDimensions.spaceMedium,
              children: [
                DashboardMenuItem(
                  title: AppStrings.scanDashboardLight,
                  icon: Icons.camera_alt,
                  iconColor: AppColors.dashboardLight,
                  onTap: () {
                    Navigator.of(context).pushNamed(AppRoutes.scanDashboardLight);
                  },
                ),
                DashboardMenuItem(
                  title: AppStrings.recordEngineSound,
                  icon: Icons.mic,
                  iconColor: AppColors.engineSound,
                  onTap: () {
                    Navigator.of(context).pushNamed(AppRoutes.recordEngineSound);
                  },
                ),
                DashboardMenuItem(
                  title: AppStrings.findMechanic,
                  icon: Icons.location_on,
                  iconColor: AppColors.primaryDark,
                  onTap: () {
                    Navigator.of(context).pushNamed(AppRoutes.findMechanic);
                  },
                ),
                DashboardMenuItem(
                  title: AppStrings.viewHistory,
                  icon: Icons.history,
                  iconColor: AppColors.secondaryDark,
                  onTap: () {
                    Navigator.of(context).pushNamed(AppRoutes.history);
                  },
                ),
              ],
            ),
            const SizedBox(height: AppDimensions.spaceLarge),
            // You can add more sections here, e.g., quick tips, car maintenance reminders, etc.
          ],
        ),
      ),
    );
  }
}