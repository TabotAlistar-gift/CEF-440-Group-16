import 'package:flutter/material.dart';
import '../../../../core/constants/app_colors.dart';
import '../../../../core/constants/app_dimensions.dart';
import '../../../../core/constants/app_strings.dart';
import '../../../../core/utils/helpers.dart'; // For toast messages

class SettingsPage extends StatelessWidget {
  const SettingsPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        title: const Text(AppStrings.settingsTitle),
      ),
      body: ListView(
        padding: const EdgeInsets.all(AppDimensions.paddingMedium),
        children: [
          _buildSettingsCategory(
            context,
            title: AppStrings.generalSettings,
            children: [
              _buildSettingsTile(
                context,
                title: AppStrings.notifications,
                icon: Icons.notifications,
                trailing: Switch(
                  value: true, // Example value
                  onChanged: (bool value) {
                    // Handle notification toggle
                    Helpers.showToast('Notifications toggled: $value');
                  },
                  activeColor: AppColors.primary,
                ),
              ),
              _buildSettingsTile(
                context,
                title: AppStrings.appTheme,
                icon: Icons.brightness_6,
                trailing: DropdownButton<String>(
                  value: 'Light', // Example value
                  onChanged: (String? newValue) {
                    // Handle theme change
                    Helpers.showToast('Theme changed to: $newValue');
                  },
                  items: <String>['Light', 'Dark']
                      .map<DropdownMenuItem<String>>((String value) {
                    return DropdownMenuItem<String>(
                      value: value,
                      child: Text(value),
                    );
                  }).toList(),
                ),
              ),
            ],
          ),
          const SizedBox(height: AppDimensions.spaceLarge),
          _buildSettingsCategory(
            context,
            title: 'About',
            children: [
              _buildSettingsTile(
                context,
                title: AppStrings.privacyPolicy,
                icon: Icons.privacy_tip,
                onTap: () {
                  // Navigate to Privacy Policy page or open URL
                  Helpers.showToast('Privacy Policy');
                },
              ),
              _buildSettingsTile(
                context,
                title: AppStrings.termsOfService,
                icon: Icons.description,
                onTap: () {
                  // Navigate to Terms of Service page or open URL
                  Helpers.showToast('Terms of Service');
                },
              ),
              _buildSettingsTile(
                context,
                title: AppStrings.aboutApp,
                icon: Icons.info,
                onTap: () {
                  showAboutDialog(
                    context: context,
                    applicationName: AppStrings.appName,
                    applicationVersion: '1.0.0',
                    applicationLegalese: '© 2024 Your Company. All rights reserved.',
                    children: [
                      const Text('This app helps diagnose car faults and find mechanics.'),
                    ],
                  );
                },
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildSettingsCategory(BuildContext context, {required String title, required List<Widget> children}) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.only(left: AppDimensions.paddingSmall, bottom: AppDimensions.paddingSmall),
          child: Text(
            title,
            style: Theme.of(context).textTheme.titleLarge?.copyWith(
                  color: AppColors.primaryDark,
                  fontWeight: FontWeight.bold,
                ),
          ),
        ),
        Card(
          elevation: 1,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(AppDimensions.borderRadiusLarge),
          ),
          child: Column(
            children: children
                .asMap()
                .entries
                .map((entry) {
                  final int index = entry.key;
                  final Widget tile = entry.value;
                  return Column(
                    children: [
                      tile,
                      if (index < children.length - 1)
                        Padding(
                          padding: const EdgeInsets.symmetric(horizontal: AppDimensions.paddingMedium),
                          child: Divider(color: AppColors.divider.withOpacity(0.5), height: 1),
                        ),
                    ],
                  );
                })
                .toList(),
          ),
        ),
      ],
    );
  }

  Widget _buildSettingsTile(
    BuildContext context, {
    required String title,
    required IconData icon,
    Widget? trailing,
    VoidCallback? onTap,
  }) {
    return ListTile(
      leading: Icon(icon, color: AppColors.primary),
      title: Text(title, style: Theme.of(context).textTheme.bodyLarge),
      trailing: trailing ?? const Icon(Icons.chevron_right, color: AppColors.textSecondary),
      onTap: onTap,
      contentPadding: const EdgeInsets.symmetric(horizontal: AppDimensions.paddingMedium),
      visualDensity: VisualDensity.compact, // Reduce vertical padding
    );
  }
}