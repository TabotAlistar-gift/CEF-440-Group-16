import 'package:car_fault_diagnosis/config/routes/app_routes.dart';
import 'package:car_fault_diagnosis/features/auth/domain/entities/user.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../../../../core/constants/app_colors.dart';
import '../../../../core/constants/app_dimensions.dart';
import '../../../../core/constants/app_strings.dart';
import '../../../../core/utils/formatters.dart';
import '../../../auth/presentation/bloc/auth_bloc.dart';

class ProfilePage extends StatelessWidget {
  const ProfilePage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        title: const Text(AppStrings.profileTitle),
      ),
      body: BlocBuilder<AuthBloc, AuthState>(
        builder: (context, state) {
          if (state is AuthLoading) {
            return const Center(child: CircularProgressIndicator());
          } else if (state is AuthSuccess) {
            final user = state.user;
            return SingleChildScrollView(
              padding: const EdgeInsets.all(AppDimensions.paddingLarge),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  CircleAvatar(
                    radius: 70,
                    backgroundColor: AppColors.primary.withOpacity(0.2),
                    child: Icon(
                      user.userType == UserType.carOwner ? Icons.directions_car : Icons.build,
                      size: AppDimensions.iconSizeXLarge * 1.5,
                      color: AppColors.primary,
                    ),
                  ),
                  const SizedBox(height: AppDimensions.spaceLarge),
                  Text(
                    user.name,
                    style: Theme.of(context).textTheme.displayLarge,
                  ),
                  const SizedBox(height: AppDimensions.spaceSmall),
                  Text(
                    user.email,
                    style: Theme.of(context).textTheme.titleLarge?.copyWith(
                          color: AppColors.textSecondary,
                        ),
                  ),
                  const SizedBox(height: AppDimensions.spaceSmall),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: AppDimensions.paddingMedium, vertical: AppDimensions.paddingSmall),
                    decoration: BoxDecoration(
                      color: AppColors.secondary.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(AppDimensions.borderRadiusLarge),
                    ),
                    child: Text(
                      Formatters.capitalize(user.userType.toString().split('.').last),
                      style: Theme.of(context).textTheme.titleLarge?.copyWith(
                            color: AppColors.secondaryDark,
                            fontWeight: FontWeight.bold,
                          ),
                    ),
                  ),
                  const SizedBox(height: AppDimensions.spaceLarge * 2),
                  ListTile(
                    leading: const Icon(Icons.calendar_today, color: AppColors.primary),
                    title: const Text('Member Since'),
                    subtitle: Text(Formatters.formatDate(user.createdAt)),
                    titleTextStyle: Theme.of(context).textTheme.headlineSmall,
                    subtitleTextStyle: Theme.of(context).textTheme.bodyLarge,
                  ),
                  const Divider(color: AppColors.divider),
                  ListTile(
                    leading: const Icon(Icons.phone, color: AppColors.primary),
                    title: const Text('Phone Number'),
                    subtitle: const Text('N/A (Add your number)'), // Placeholder
                    titleTextStyle: Theme.of(context).textTheme.headlineSmall,
                    subtitleTextStyle: Theme.of(context).textTheme.bodyLarge,
                    trailing: IconButton(
                      icon: const Icon(Icons.edit, color: AppColors.textSecondary),
                      onPressed: () {
                        // Implement edit phone number
                      },
                    ),
                  ),
                  const Divider(color: AppColors.divider),
                  ListTile(
                    leading: const Icon(Icons.edit, color: AppColors.primary),
                    title: const Text(AppStrings.editProfile),
                    onTap: () {
                      // Navigate to edit profile page
                    },
                    trailing: const Icon(Icons.chevron_right),
                  ),
                  const Divider(color: AppColors.divider),
                  ListTile(
                    leading: const Icon(Icons.logout, color: AppColors.error),
                    title: const Text(AppStrings.logout),
                    onTap: () {
                      context.read<AuthBloc>().add(LogoutEvent());
                    },
                  ),
                ],
              ),
            );
          } else if (state is AuthError || state is AuthInitial) {
            return Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(AppStrings.somethingWentWrong, style: Theme.of(context).textTheme.headlineMedium),
                  const SizedBox(height: AppDimensions.spaceMedium),
                  TextButton(
                    onPressed: () {
                      // Attempt to re-check auth or navigate to login
                      Navigator.of(context).pushReplacementNamed(AppRoutes.login);
                    },
                    child: const Text('Go to Login'),
                  )
                ],
              ),
            );
          }
          return const Center(child: Text('Unknown state'));
        },
      ),
    );
  }
}